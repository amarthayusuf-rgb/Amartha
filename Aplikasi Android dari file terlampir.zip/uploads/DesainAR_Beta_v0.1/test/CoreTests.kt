import id.desainar.core.*
import kotlin.math.*
import java.util.Random

var fails = 0
fun check(name: String, ok: Boolean, info: String = "") {
    println((if (ok) "OK   " else "GAGAL") + "  " + name + (if (info.isNotEmpty()) "  [$info]" else ""))
    if (!ok) fails++
}

fun main() {
    // 1. UTM vs pyproj EPSG:32750
    val ref = listOf(
        doubleArrayOf(-1.13, 115.2, 299710.6133047475, 9875038.82493182, 0.03550961119990353),
        doubleArrayOf(-1.15, 115.25, 305277.31756901566, 9872830.578808269, 0.03513353618104493),
        doubleArrayOf(-0.95, 116.9, 488874.01731469505, 9894996.198596964, 0.0016579885376693932),
        doubleArrayOf(-6.2, 106.8, -634315.9202361829, 9303694.464736845, 1.1134783889448856),
        doubleArrayOf(-1.1314, 115.2311, 303172.3792786397, 9874886.13490523, 0.034938910714268294)
    )
    for (r in ref) {
        val en = Utm.forward(r[0], r[1], 50, true)
        val err = hypot(en[0] - r[2], en[1] - r[3])
        check("UTM lat=${r[0]} lon=${r[1]}", err < 0.001 || (abs(r[1] - 117) > 9 && err < 0.05), "err=%.6f m".format(err))
        val g = Utm.gridAzOfTrueNorth(r[0], r[1], 50, true)
        check("  konvergensi", abs(g + r[4]) < 1e-4, "kotlin=%.6f pyproj=-%.6f".format(g, r[4]))
    }

    // 2. Frames round trip + konvensi azimut
    val p = AlignParams(Math.toRadians(37.0), 120.5, -45.2, 88.0)
    val q = Frames.arToEnu(p, 3.0, 1.5, -7.0)
    val back = Frames.enuToAr(p, q[0], q[1], q[2])
    check("round trip AR<->ENU", abs(back[0] - 3.0) < 1e-9 && abs(back[1] - 1.5) < 1e-9 && abs(back[2] + 7.0) < 1e-9)
    // kamera AR melihat ke -Z (azimut AR 0). theta 37 deg => azimut ENU = -37 = 323
    val d = Frames.dirArToEnu(p, 0.0, 0.0, -1.0)
    check("az_enu = az_ar - theta", abs(Frames.azimuthDeg(d[0], d[1]) - 323.0) < 1e-9, "az=%.4f".format(Frames.azimuthDeg(d[0], d[1])))

    // 3. fromCompass
    val fwd = doubleArrayOf(sin(Math.toRadians(20.0)), -0.1, -cos(Math.toRadians(20.0)))   // azimut AR 20 deg
    val a0 = Aligner.fromCompass(1.0, 1.6, 2.0, fwd[0], fwd[1], fwd[2], 500.0, 600.0, 70.0, 110.0)
    val dd = Frames.dirArToEnu(a0, fwd[0], fwd[1], fwd[2])
    val cc = Frames.arToEnu(a0, 1.0, 1.6, 2.0)
    check("fromCompass azimut", abs(Frames.azimuthDeg(dd[0], dd[1]) - 110.0) < 1e-6, "az=%.5f".format(Frames.azimuthDeg(dd[0], dd[1])))
    check("fromCompass posisi", abs(cc[0] - 500) < 1e-9 && abs(cc[1] - 600) < 1e-9 && abs(cc[2] - 70) < 1e-9)

    // 4. Fit yaw+translasi dari lintasan RTK (sigma 2 cm), jalan 30 m
    val rnd = Random(1)
    val truth = AlignParams(Math.toRadians(-63.0), 250.0, -130.0, 75.0)
    val samples = ArrayList<GnssSample>()
    for (i in 0 until 40) {
        val x = i * 0.75; val z = -i * 0.2 + sin(i * 0.3); val y = 1.5
        val e = Frames.arToEnu(truth, x, y, z)
        samples.add(GnssSample(x, y, z, e[0] + rnd.nextGaussian() * 0.02, e[1] + rnd.nextGaussian() * 0.02, e[2] + rnd.nextGaussian() * 0.04, 0.02, 0.04))
    }
    val fit = Aligner.fitYawAndTranslation(samples)!!
    val dth = Math.toDegrees(fit.first.theta - truth.theta)
    check("fit RTK heading", abs(dth) < 0.2, "err=%.3f deg, sigma est=%.3f".format(dth, fit.second))
    check("fit RTK translasi", hypot(fit.first.tx - truth.tx, fit.first.ty - truth.ty) < 0.1, "err=%.3f m".format(hypot(fit.first.tx - truth.tx, fit.first.ty - truth.ty)))

    // 5. Bidikan titik kontrol: prior dari kompas salah 12 deg, GNSS salah 4 m, tinggi salah 15 m
    val cps = listOf(doubleArrayOf(380.0, 210.0, 52.0), doubleArrayOf(120.0, 330.0, 61.0), doubleArrayOf(260.0, 40.0, 45.0))
    fun sightings(k: Int, noiseDeg: Double): List<Sighting> {
        val list = ArrayList<Sighting>()
        for (i in 0 until k) {
            val cam = doubleArrayOf(0.5 * i, 1.6, -0.3 * i)            // kamera AR bergerak sedikit
            val ce = Frames.arToEnu(truth, cam[0], cam[1], cam[2])
            val v = doubleArrayOf(cps[i][0] - ce[0], cps[i][1] - ce[1], cps[i][2] - ce[2])
            // arah ENU -> arah AR (rotasi balik), tambah noise sudut
            val az = atan2(v[0], v[1]) + Math.toRadians(rnd.nextGaussian() * noiseDeg)
            val el = atan2(v[2], hypot(v[0], v[1])) + Math.toRadians(rnd.nextGaussian() * noiseDeg)
            val de = sin(az) * cos(el); val dn = cos(az) * cos(el); val du = sin(el)
            val c = cos(-truth.theta); val s = sin(-truth.theta)
            val e0 = c * de - s * dn; val n0 = s * de + c * dn
            list.add(Sighting(cam[0], cam[1], cam[2], e0, du, -n0, cps[i][0], cps[i][1], cps[i][2], "CP$i"))
        }
        return list
    }
    val prior = AlignParams(truth.theta + Math.toRadians(12.0), truth.tx + 3.0, truth.ty - 2.5, truth.tz + 15.0)
    val r1 = Aligner.solveSightings(sightings(1, 0.15), prior, 5.0, 20.0)
    check("1 titik: heading", abs(Math.toDegrees(r1.params.theta - truth.theta)) < 1.5,
        "err=%.3f deg (prior 12 deg)".format(Math.toDegrees(r1.params.theta - truth.theta)))
    check("1 titik: tinggi", abs(r1.params.tz - truth.tz) < 3.0, "err=%.2f m (prior 15 m)".format(r1.params.tz - truth.tz))
    val r0 = Aligner.solveSightings(sightings(3, 0.0), prior, 1000.0, 1000.0, 0.3, 1000.0)
    check("3 titik tanpa noise, prior longgar: solver eksak", abs(Math.toDegrees(r0.params.theta - truth.theta)) < 0.01 && hypot(r0.params.tx - truth.tx, r0.params.ty - truth.ty) < 0.05 && abs(r0.params.tz - truth.tz) < 0.05,
        "dth=%.4f deg dpos=%.3f m dz=%.3f m".format(Math.toDegrees(r0.params.theta - truth.theta), hypot(r0.params.tx - truth.tx, r0.params.ty - truth.ty), r0.params.tz - truth.tz))
    val r3 = Aligner.solveSightings(sightings(3, 0.15), prior, 5.0, 20.0)
    // metrik yang penting: salah arah garis desain di layar (derajat) untuk titik 100-500 m
    fun overlayErrDeg(sol: AlignParams): DoubleArray {
        val cam = doubleArrayOf(0.0, 1.6, 0.0)
        val errs = ArrayList<Double>()
        val ce = Frames.arToEnu(truth, cam[0], cam[1], cam[2])
        for (k in 0 until 200) {
            val az = Math.toRadians(-30.0 + 60.0 * rnd.nextDouble()) + atan2(cps[0][0] - ce[0], cps[0][1] - ce[1])
            val dist = 100.0 + 400.0 * rnd.nextDouble()
            val pe = ce[0] + dist * sin(az); val pn = ce[1] + dist * cos(az); val pu = 50.0 + 20 * rnd.nextDouble()
            val a = Frames.enuToAr(truth, pe, pn, pu); val b = Frames.enuToAr(sol, pe, pn, pu)
            val va = doubleArrayOf(a[0] - cam[0], a[1] - cam[1], a[2] - cam[2]); val vb = doubleArrayOf(b[0] - cam[0], b[1] - cam[1], b[2] - cam[2])
            val dot = va[0] * vb[0] + va[1] * vb[1] + va[2] * vb[2]
            val cr = sqrt((va[1] * vb[2] - va[2] * vb[1]).pow(2) + (va[2] * vb[0] - va[0] * vb[2]).pow(2) + (va[0] * vb[1] - va[1] * vb[0]).pow(2))
            errs.add(Math.toDegrees(atan2(cr, dot)))
        }
        errs.sort()
        return doubleArrayOf(errs[errs.size / 2], errs[(errs.size * 9) / 10])
    }
    val ePrior = overlayErrDeg(prior)
    val e1 = overlayErrDeg(r1.params)
    val e3 = overlayErrDeg(r3.params)
    println("      salah arah overlay (median/p90 deg): prior %.2f/%.2f | 1 titik %.3f/%.3f | 3 titik %.3f/%.3f".format(ePrior[0], ePrior[1], e1[0], e1[1], e3[0], e3[1]))
    check("1 titik: salah arah overlay < 1 deg", e1[0] < 1.0)
    check("3 titik: salah arah overlay < 0.4 deg", e3[0] < 0.4)
    check("3 titik: heading", abs(Math.toDegrees(r3.params.theta - truth.theta)) < 0.3, "err=%.3f deg".format(Math.toDegrees(r3.params.theta - truth.theta)))
    println("      (info) 3 titik posisi err=%.2f m, tinggi err=%.2f m, rms=%.3f deg".format(hypot(r3.params.tx - truth.tx, r3.params.ty - truth.ty), r3.params.tz - truth.tz, r3.rmsDeg))

    // 5b. arah tombol geser: theta - 1 deg => garis bergeser ke KIRI (x AR negatif); tz + 1 => garis TURUN
    val base = AlignParams(0.0, 0.0, 0.0, 0.0)
    val left = Frames.enuToAr(base.copy(theta = Math.toRadians(-1.0)), 0.0, 100.0, 0.0)
    check("tombol ◀ menggeser garis ke kiri", left[0] < 0, "x=%.3f".format(left[0]))
    val down = Frames.enuToAr(base.copy(tz = 1.0), 0.0, 100.0, 0.0)
    check("tombol ▼ (tz+1) menurunkan garis", down[1] < 0, "y=%.3f".format(down[1]))

    // 6. DEM raycast: bidang miring z = 50 + 0.1*e
    val nx = 200; val ny = 200; val cs = 2.0
    val data = FloatArray(nx * ny)
    for (r in 0 until ny) for (c in 0 until nx) { val e = (c + 0.5) * cs; data[r * nx + c] = (50 + 0.1 * e).toFloat() }
    val dem = DemGrid(0.0, 400.0, cs, nx, ny, data)
    check("DEM sample", abs(dem.sample(101.0, 200.0) - 60.1) < 1e-4, "z=%.4f".format(dem.sample(101.0, 200.0)))
    val hit = dem.raycast(doubleArrayOf(10.0, 200.0, 80.0), doubleArrayOf(1.0, 0.0, -0.2))
    // 80 - 0.2 s = 50 + 0.1(10 + s) -> s = 29/0.3 = 96.667
    val sExp = 29.0 / 0.3 * sqrt(1.04)   // jarak sepanjang arah ternormalisasi
    check("DEM raycast", hit != null && abs(hit[3] - sExp) < 0.01, "s=%.4f exp=%.4f".format(hit?.get(3) ?: -1.0, sExp))

    // 7. Proyeksi: view identitas, proyeksi perspektif fov 60
    val f = 1f / tan(Math.toRadians(30.0)).toFloat(); val near = 0.1f; val far = 1000f
    val proj = floatArrayOf(f / (16f / 9f), 0f, 0f, 0f, 0f, f, 0f, 0f, 0f, 0f, (far + near) / (near - far), -1f, 0f, 0f, 2 * far * near / (near - far), 0f)
    val view = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
    val vp = Mat4.mul(proj, view)
    val pc = Projector.projectPoint(vp, 0.0, 0.0, -10.0, 1920, 1080)
    check("proyeksi titik tengah", pc != null && abs(pc[0] - 960) < 0.01 && abs(pc[1] - 540) < 0.01)
    val segs = Projector.projectPolyline(doubleArrayOf(-1.0, 0.0, -10.0, 1.0, 0.0, -10.0, 1.0, 0.0, 5.0), vp, 1920, 1080)
    check("kliping bidang dekat", segs.isNotEmpty() && segs.all { s -> s.all { it.isFinite() } }, "potongan=${segs.size}")
    val inv = Mat4.invert(vp)!!
    val ray = Projector.unproject(inv, 960f, 540f, 1920, 1080)
    check("unproject arah -Z", abs(ray[3]) < 1e-3 && abs(ray[4]) < 1e-3 && ray[5] < 0)

    println(if (fails == 0) "\nSEMUA UJI LULUS" else "\n$fails UJI GAGAL")
    if (fails > 0) System.exit(1)
}
