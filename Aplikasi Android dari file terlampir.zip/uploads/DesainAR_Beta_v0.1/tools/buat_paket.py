#!/usr/bin/env python3
"""
buat_paket.py — membuat paket desain (.zip) untuk aplikasi DesainAR Beta (Android).

Contoh (Pit MSAL, Oktober 2026):
  python buat_paket.py --nama "BDA Okt 2026" ^
      --dxf pit=mp_2610_1_5_r1.dxf --dxf dsp=dsp_okt_r0.dxf ^
      --topo sit_all_260925_ctr_c.dxf --desain sit_eom_oct26.dxf ^
      --titik titik_kontrol.csv --cs 4 --out paket_bda_okt26.zip

Isi zip:
  manifest.json   origin UTM, EPSG, info DEM, titik kontrol (koordinat lokal = UTM - origin)
  lines.json      lapisan + garis 3D (vertex DXF dgn Z desain sendiri, disederhanakan) + label RL
  dem_topo.bin    float32 little-endian, baris utara->selatan (opsional, untuk tanda + dan tinggi kamera)
  dem_design.bin  float32 little-endian (opsional, untuk RL desain & gali/timbun)

Butuh: pip install ezdxf numpy scipy
"""
import argparse, csv, io, json, math, os, sys, time, zipfile
import numpy as np

# gaya bawaan = standar warna DXF desain BDA (ACI): [src, ACI, label, warna, tebal_dp, toleransi_DP_m]
GAYA_BAWAAN = [
    ["pit", 6, "Batas Desain Pit", "#FF00FF", 2.5, 4.0],
    ["pit", 3, "Crest Line", "#00FF00", 2.5, 0.3],
    ["pit", 1, "Toe Line", "#FF0000", 2.5, 0.3],
    ["pit", 4, "Plan Jalan / Ramp", "#00FFFF", 2.0, 1.5],
    ["dsp", 30, "Limit Line Disposal", "#FFA000", 2.5, 4.0],
    ["dsp", 3, "Crest Line", "#00FF00", 2.5, 0.3],
    ["dsp", 1, "Toe Line", "#FF0000", 2.5, 0.3],
    ["dsp", 4, "Plan Jalan / Ramp", "#00FFFF", 2.0, 1.5],
    ["dsp", 5, "Saluran / Channel", "#3C78FF", 2.0, 1.5],
    ["dsp", 94, "Ramp", "#00AA00", 2.0, 0.3],
    ["dsp", 7, "Tepi Jalan / Pad", "#FFFFFF", 1.5, 1.5],
    ["dsp", 255, "Tepi Jalan / Pad", "#FFFFFF", 1.5, 1.5],
]


def log(*a):
    print(*a, flush=True)


# ------------------------------------------------------------------ DXF
def baca_dxf(path):
    import ezdxf
    out = []
    for e in ezdxf.readfile(path).modelspace():
        t = e.dxftype(); c = e.dxf.color
        if t == 'LWPOLYLINE':
            p = np.array(e.get_points('xy'))
            if len(p) < 2: continue
            P = np.c_[p, np.full(len(p), e.dxf.elevation)]
            if e.closed: P = np.vstack([P, P[:1]])
        elif t == 'POLYLINE':
            P = np.array([list(v.dxf.location) for v in e.vertices])
            if len(P) < 2: continue
            if e.is_closed: P = np.vstack([P, P[:1]])
        elif t == 'LINE':
            P = np.array([list(e.dxf.start), list(e.dxf.end)])
        elif t == 'TEXT':
            out.append(dict(t=t, c=c, P=np.array([list(e.dxf.insert)]), text=e.dxf.text, ht=e.dxf.height)); continue
        else:
            continue
        out.append(dict(t=t, c=c, P=P))
    return out


def titik_kontur(path):
    """Semua vertex kontur/garis (X,Y,Z) dari DXF topo/desain, buang entitas di origin."""
    import ezdxf
    pts = []
    for e in ezdxf.readfile(path).modelspace():
        t = e.dxftype()
        if t == 'LWPOLYLINE':
            p = np.array(e.get_points('xy'))
            if len(p): pts.append(np.c_[p, np.full(len(p), e.dxf.elevation)])
        elif t == 'POLYLINE':
            p = np.array([list(v.dxf.location) for v in e.vertices])
            if len(p): pts.append(p)
        elif t == 'LINE':
            pts.append(np.array([list(e.dxf.start), list(e.dxf.end)]))
        elif t == 'POINT':
            pts.append(np.array([list(e.dxf.location)]))
    P = np.vstack(pts)
    return P[P[:, 0] > 1000]


def _dp_idx(XY, tol):
    n = len(XY)
    if n < 3: return list(range(n))
    keep = np.zeros(n, bool); keep[0] = keep[-1] = True; st = [(0, n - 1)]
    while st:
        i, j = st.pop()
        if j <= i + 1: continue
        seg = XY[j] - XY[i]; L = np.hypot(*seg); Q = XY[i + 1:j] - XY[i]
        d = np.hypot(Q[:, 0], Q[:, 1]) if L < 1e-9 else np.abs(seg[0] * Q[:, 1] - seg[1] * Q[:, 0]) / L
        k = int(np.argmax(d))
        if d[k] > tol:
            keep[i + 1 + k] = True; st += [(i, i + 1 + k), (i + 1 + k, j)]
    return list(np.where(keep)[0])


def sederhanakan(P, tol):
    """Douglas-Peucker di XY; vertex 3D asli dipertahankan supaya garis tetap lurus."""
    if len(P) < 3 or tol <= 0: return P
    XY = P[:, :2].astype(float)
    if np.hypot(*(XY[0] - XY[-1])) < 1e-6:
        far = int(np.argmax(np.hypot(*(XY - XY[0]).T)))
        idx = _dp_idx(XY[:far + 1], tol) + [far + k for k in _dp_idx(XY[far:], tol)][1:]
    else:
        idx = _dp_idx(XY, tol)
    return P[idx]


# ------------------------------------------------------------------ DEM
def buat_dem(pts, x0, y0, cs, nx, ny):
    """TIN linear dari titik kontur -> grid (baris utara->selatan), nodata -9999."""
    from scipy.interpolate import LinearNDInterpolator
    from scipy.spatial import Delaunay
    pad = 3 * cs
    m = (pts[:, 0] > x0 - pad) & (pts[:, 0] < x0 + nx * cs + pad) & (pts[:, 1] < y0 + pad) & (pts[:, 1] > y0 - ny * cs - pad)
    pts = pts[m]
    k = np.round(pts[:, :2] / 0.5).astype(np.int64)
    _, idx = np.unique(k[:, 0] * 100000000 + k[:, 1], return_index=True)
    pts = pts[idx]
    log(f'    TIN dari {len(pts):,} titik...')
    f = LinearNDInterpolator(Delaunay(pts[:, :2]), pts[:, 2])
    xs = x0 + (np.arange(nx) + 0.5) * cs
    ys = y0 - (np.arange(ny) + 0.5) * cs
    Z = np.empty((ny, nx), np.float32)
    for i in range(0, ny, 200):
        XX, YY = np.meshgrid(xs, ys[i:i + 200]); Z[i:i + 200] = f(XX, YY)
    Z[~np.isfinite(Z)] = -9999.0
    return Z


class Grid:
    def __init__(self, Z, x0, y0, cs):
        self.Z, self.x0, self.y0, self.cs = Z, x0, y0, cs

    def at(self, x, y):
        from scipy.ndimage import map_coordinates
        c = (np.asarray(x) - self.x0) / self.cs - 0.5
        r = (self.y0 - np.asarray(y)) / self.cs - 0.5
        Zn = np.where(self.Z <= -9998, np.nan, self.Z)
        return map_coordinates(Zn, [np.atleast_1d(r), np.atleast_1d(c)], order=1, mode='nearest', prefilter=False)


# ------------------------------------------------------------------ utama
def main():
    ap = argparse.ArgumentParser(description='Buat paket desain .zip untuk DesainAR Beta')
    ap.add_argument('--nama', required=True)
    ap.add_argument('--dxf', action='append', required=True, help='src=file.dxf (src cocok dengan kolom 1 gaya: pit / dsp)')
    ap.add_argument('--gaya', help='JSON daftar [src, ACI, label, warna, tebal, toleransi]; default gaya BDA')
    ap.add_argument('--topo', help='DXF kontur situasi terbaru (untuk tanda + dan tinggi kamera)')
    ap.add_argument('--desain', help='DXF permukaan desain tempel-topo (untuk RL desain / gali-timbun)')
    ap.add_argument('--titik', help='CSV titik kontrol: nama,E,N,RL (header bebas, baris # diabaikan)')
    ap.add_argument('--epsg', type=int, default=32750, help='EPSG UTM WGS84 (326xx utara / 327xx selatan). Default 32750')
    ap.add_argument('--cs', type=float, default=4.0, help='ukuran sel DEM (m). Default 4')
    ap.add_argument('--buffer', type=float, default=600.0, help='perluasan DEM di sekitar desain (m). Default 600')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    t0 = time.time()

    if not (32601 <= a.epsg <= 32660 or 32701 <= a.epsg <= 32760):
        sys.exit('EPSG harus UTM WGS84 (32601-32660 / 32701-32760)')
    zone = a.epsg % 100; south = a.epsg >= 32700
    gaya = json.load(open(a.gaya)) if a.gaya else GAYA_BAWAAN
    sty = {(g[0], int(g[1])): g for g in gaya}

    # lapisan unik per label
    layers, layer_id = [], {}
    for g in gaya:
        if g[2] not in layer_id:
            lid = 'L%02d' % len(layers)
            layer_id[g[2]] = lid
            layers.append(dict(id=lid, label=g[2], color=g[3], width=float(g[4]), visible=True))

    # garis desain
    raw = []
    labels_raw = []
    for spec in a.dxf:
        src, path = spec.split('=', 1)
        log(f'Baca desain {src}: {path}')
        n_ok = 0
        for e in baca_dxf(path):
            if e['P'][:, 0].min() < 1000: continue          # anotasi di origin
            if e['t'] == 'TEXT':
                if e['text'].strip().upper().startswith('RL'):
                    labels_raw.append((e['text'].replace('RL+', 'RL +'), e['P'][0], e['ht']))
                continue
            g = sty.get((src, int(e['c'])))
            if not g: continue
            raw.append((g, e['P'].astype(float))); n_ok += 1
        log(f'    {n_ok} garis cocok gaya')
    if not raw:
        sys.exit('Tidak ada garis yang cocok dengan gaya. Cek kode warna ACI di DXF.')

    allp = np.vstack([P for _, P in raw])
    xmin, ymin = allp[:, 0].min() - a.buffer, allp[:, 1].min() - a.buffer
    xmax, ymax = allp[:, 0].max() + a.buffer, allp[:, 1].max() + a.buffer
    oE = round((xmin + xmax) / 2 / 100) * 100.0
    oN = round((ymin + ymax) / 2 / 100) * 100.0
    cs = a.cs
    nx = int(math.ceil((xmax - xmin) / cs)); ny = int(math.ceil((ymax - ymin) / cs))
    gx0, gy0 = xmin, ymax                                  # sudut barat-laut (absolut)
    log(f'Area {xmax - xmin:.0f} x {ymax - ymin:.0f} m, origin ({oE:.0f}, {oN:.0f}), DEM {nx} x {ny} @ {cs} m')

    files = {}
    man = dict(format='desainar-1', name=a.nama, epsg=a.epsg, utm_zone=zone, south=south,
               origin=[oE, oN], dibuat=time.strftime('%Y-%m-%d %H:%M'), sumber=[s for s in a.dxf],
               notes='Koordinat lokal = UTM - origin. Elevasi = RL tambang.')
    gdes = None
    for key, path in (('dem_topo', a.topo), ('dem_design', a.desain)):
        if not path: continue
        log(f'DEM {key}: {path}')
        Z = buat_dem(titik_kontur(path), gx0, gy0, cs, nx, ny)
        valid = Z > -9998
        log(f'    RL {Z[valid].min():.1f} .. {Z[valid].max():.1f}, terisi {valid.mean() * 100:.1f}%')
        files[key + '.bin'] = Z.astype('<f4').tobytes()
        man[key] = dict(file=key + '.bin', x0=gx0 - oE, y0=gy0 - oN, cs=cs, nx=nx, ny=ny, nodata=-9999.0)
        if key == 'dem_design':
            gdes = Grid(Z, gx0, gy0, cs)

    # sederhanakan + Z
    lines, seen, nv0, nv1, nz = [], set(), 0, 0, 0
    for g, P in raw:
        nv0 += len(P)
        noz = np.abs(P[:, 2]) < 1.0
        if noz.any() and gdes is not None:
            P[noz, 2] = gdes.at(P[noz, 0], P[noz, 1]); nz += int(noz.sum())
        P = sederhanakan(P, float(g[5]))
        key = (layer_id[g[2]], tuple(np.round(P[:, :2].ravel(), 1)))
        if key in seen: continue                             # DXF sering memuat entitas ganda
        seen.add(key)
        nv1 += len(P)
        lines.append(dict(layer=layer_id[g[2]],
                          pts=[[round(x - oE, 3), round(y - oN, 3), round(z, 3)] for x, y, z in P]))
    log(f'Garis: {len(lines)} (vertex {nv0} -> {nv1}; {nz} vertex tanpa Z diisi dari DEM desain)')

    labels = []
    for text, p, ht in sorted(labels_raw, key=lambda t: -t[2]):
        z = float(gdes.at(p[0], p[1])[0]) if gdes is not None else float(p[2])
        if not np.isfinite(z): z = float(p[2])
        labels.append(dict(text=text, e=round(p[0] - oE, 2), n=round(p[1] - oN, 2), u=round(z, 2)))

    cps = []
    if a.titik:
        with open(a.titik, newline='', encoding='utf-8-sig') as f:
            for row in csv.reader(f):
                if not row or row[0].strip().startswith('#'): continue
                try:
                    nm, E, N, Z = row[0].strip(), float(row[1]), float(row[2]), float(row[3])
                except (ValueError, IndexError):
                    continue                                   # baris header
                cps.append(dict(name=nm, e=round(E - oE, 3), n=round(N - oN, 3), u=round(Z, 3)))
        log(f'Titik kontrol: {len(cps)}')
    man['control_points'] = cps
    man['lines_file'] = 'lines.json'

    files['lines.json'] = json.dumps(dict(layers=[l for l in layers if any(x['layer'] == l['id'] for x in lines)],
                                          lines=lines, labels=labels), separators=(',', ':')).encode()
    files['manifest.json'] = json.dumps(man, indent=1).encode()
    with zipfile.ZipFile(a.out, 'w', zipfile.ZIP_DEFLATED) as z:
        for k, v in files.items():
            z.writestr(k, v)
    log(f'Selesai: {a.out} ({os.path.getsize(a.out) / 1e6:.1f} MB) dalam {time.time() - t0:.0f} dtk')


if __name__ == '__main__':
    main()
