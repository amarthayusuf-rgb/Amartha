# DesainAR Beta — garis desain tambang di kamera HP (Android, ARCore)

Versi **0.1-beta**, 3 Oktober 2026. Dibuat dari skill *3d-to-image* (Pit MSAL, HPU-BDA).

## 1. Apa yang bisa dilakukan

| Fitur | Keterangan |
|---|---|
| Kamera live + garis desain 3D | Crest, toe, batas pit, limit disposal, jalan, saluran, label RL. Garis memakai vertex DXF dengan Z desainnya sendiri, jadi lurus dan tegas |
| Penyelarasan awal otomatis | GPS + kompas HP (kasar) |
| Kalibrasi titik kontrol | Berdiri di atas BM dan/atau membidik BM/patok dengan tanda + di tengah layar → tombol **KUNCI** |
| GNSS RTK eksternal | Lewat aplikasi *mock location*; heading dihitung otomatis dari lintasan berjalan ≥ 15 m |
| Geser manual | Garis ◀ ▶ (1° / 0,1°), garis ▲ ▼ (1 m) |
| Pembacaan tanda + | E, N, jarak, RL topo, RL desain, **GALI / TIMBUN** (m) |
| Foto | JPG ber-overlay + JPG asli + JSON pose kamera, untuk disempurnakan dengan skill 3d-to-image di PC |
| Offline | Tidak perlu internet di lapangan, kecuali saat pertama memasang ARCore |

## 2. Akurasi yang perlu diharapkan (jujur)

Angka berikut hasil simulasi terhadap DEM dan desain Pit MSAL, objek berjarak 100 m / 300 m / 500 m:

| Mode penyelarasan | Pergeseran garis (median) | Dipakai untuk |
|---|---|---|
| GPS + kompas saja | 16 / 44 / 81 m | Hanya orientasi kasar. **Jangan dipakai untuk keputusan teknis** |
| RTK + kompas | 16 / 44 / 78 m | Sama buruknya, karena heading yang dominan |
| RTK + heading dari lintasan | 0,6 / 1,8 / 3,2 m | Pengawasan bench |
| Titik kontrol (uji sintetis, bidikan ±0,15°) | Salah arah 0,2–0,3° ≈ 0,5–1,5 m pada 100–300 m | Pengawasan bench |

Status: **belum divalidasi di lapangan.** Gunakan protokol di bagian 8 untuk mengukurnya. Overlay AR bukan data survei resmi.

## 3. Isi folder

```
DesainAR/
├─ app/                         kode aplikasi Android (Kotlin)
│  ├─ src/main/java/id/desainar/core/   matematika (UTM, penyelarasan, DEM, proyeksi) — diuji
│  ├─ src/main/java/id/desainar/app/    ARCore, kamera, overlay, sensor, UI, foto
│  └─ beta-debug.keystore       kunci tanda tangan beta (supaya update tidak perlu uninstall)
├─ .github/workflows/build-apk.yml   build APK otomatis di GitHub
├─ tools/buat_paket.py          pembuat paket desain .zip dari DXF (jalan di PC)
├─ contoh/paket_bda_okt26_contoh.zip  paket contoh Pit MSAL Okt 2026 (tanpa titik kontrol)
├─ contoh/titik_kontrol_CONTOH.csv     format CSV titik kontrol
└─ test/CoreTests.kt            uji logika inti (semua lulus)
```

## 4. Membuat APK

### Cara A — GitHub Actions (tanpa memasang Android Studio, disarankan)
1. Buat akun di github.com, lalu buat repository baru (**Private**), mis. `desainar`.
2. Upload seluruh isi folder `DesainAR` (termasuk folder `.github`).
   Paling mudah lewat **GitHub Desktop**: *Add local repository* → *Publish*.
   Upload drag-drop di web bisa melewatkan folder bertitik.
3. Buka tab **Actions** → workflow **Build APK DesainAR** berjalan otomatis (±5–10 menit).
   Kalau tidak jalan otomatis, klik **Run workflow**.
4. Setelah centang hijau: buka run tersebut → bagian **Artifacts** → unduh `DesainAR-beta-apk` (zip berisi `app-debug.apk`).
5. Kalau gagal (silang merah): salin log error dan kirim ke saya untuk diperbaiki.

### Cara B — Android Studio
1. Pasang Android Studio versi terbaru → **Open** → pilih folder `DesainAR`.
2. Tunggu *Gradle sync* selesai. Semua dependensi diunduh otomatis: AGP 8.4.0, Gradle 8.6, Kotlin 1.9.24, ARCore 1.56.0.
3. **Build → Build App Bundle(s)/APK(s) → Build APK(s)**. Hasilnya ada di `app/build/outputs/apk/debug/app-debug.apk`.
4. Atau sambungkan HP (USB debugging) dan tekan ▶ Run.

## 5. Memasang di HP
- HP **harus mendukung ARCore**. Cek daftar resmi di https://developers.google.com/ar/devices.
- Salin `app-debug.apk` ke HP → buka → izinkan *Install unknown apps* untuk aplikasi pengelola file.
- Saat pertama dibuka, aplikasi meminta izin **Kamera** dan **Lokasi**, lalu meminta memasang *Google Play Services for AR* dari Play Store bila belum ada.
- Versi baru cukup dipasang di atas versi lama. Keystore-nya tetap, jadi tidak perlu uninstall.

## 6. Membuat paket desain (di PC)

```
pip install ezdxf numpy scipy
python tools/buat_paket.py --nama "BDA Okt 2026" ^
   --dxf pit=mp_2610_1_5_r1.dxf --dxf dsp=dsp_okt_r0.dxf ^
   --topo sit_all_260925_ctr_c.dxf --desain sit_eom_oct26.dxf ^
   --titik titik_kontrol.csv --cs 4 --out paket_bda_okt26.zip
```

| Argumen | Isi |
|---|---|
| `--dxf src=file` | Desain. `src` harus cocok dengan kolom 1 gaya: `pit` atau `dsp` |
| `--topo` | Kontur situasi terbaru. Dipakai untuk tanda +, tinggi kamera, RL topo |
| `--desain` | Permukaan desain yang ditempel ke topo. Dipakai untuk RL desain dan gali/timbun |
| `--titik` | CSV `nama,E,N,RL`, koordinat UTM 50S dari surveyor |
| `--gaya gaya.json` | Kalau kode warna ACI berbeda dari standar BDA. Format: `[["pit",3,"Crest Line","#00FF00",2.5,0.3], ...]` = [src, ACI, label, warna, tebal, toleransi penyederhanaan m] |
| `--cs` | Ukuran sel DEM. 4 m menghasilkan ±7 MB untuk 4,5 × 4,3 km |

Kirim zip ke HP (USB/Drive/WA) → di aplikasi tekan **PAKET** → pilih zip.

**Titik kontrol yang baik:** patok/BM bercat, tiang, sudut beton, atau rambu yang terlihat jelas dari jauh. Sebarkan ke arah yang berbeda (selisih arah > 60°), pada jarak 100–400 m dari posisi berdiri.

## 7. Cara pakai di lapangan

1. Buka aplikasi di area terbuka. **Gerakkan HP perlahan** sampai *AR tracking OK*.
   Arahkan kamera **mendatar** (bukan ke langit atau tanah) sampai muncul garis. Ini penyelarasan kasar GPS + kompas.
2. **KALIBRASI** (wajib sebelum dipakai untuk penilaian teknis):
   - **Terbaik:** *Saya berdiri DI ATAS titik kontrol* (HP setinggi 1,5 m) → lalu *Bidik titik kontrol* lain → tempatkan tanda + tepat di titik → **KUNCI**.
   - **Tanpa berdiri di BM:** bidik 2–3 titik kontrol dari tempat yang sama (makin tersebar arahnya, makin baik).
   - HUD menampilkan *sisa x°*. Target < 0,3°. Kalau besar, salah satu bidikan atau koordinat titik keliru → *Hapus kalibrasi* lalu ulangi.
3. Halus: tombol ◀ ▶ menggeser garis ke kiri/kanan (heading), ▲ ▼ menaikkan/menurunkan garis (tinggi). Mode *Manual* mengunci GNSS.
4. **Tanda +**: arahkan ke lantai/lereng untuk membaca RL topo, RL desain, dan GALI/TIMBUN.
5. **FOTO**: tersimpan di galeri *Pictures/DesainAR*. Salinan lengkap (JPG overlay + JPG asli + JSON) ada di
   `Android/data/id.desainar.beta/files/Pictures/DesainAR/`.
6. **RESET** bila pindah lokasi jauh atau garis jelas bergeser.

### Memakai GNSS RTK eksternal
1. Pasang aplikasi penerima RTK/NTRIP yang bisa menjadi *mock location* (mis. dari vendor receiver Anda).
2. HP: *Opsi pengembang* → *Pilih aplikasi lokasi palsu* → pilih aplikasi tersebut.
3. HUD akan menampilkan `GNSS ±0.0x m (RTK)`. Berjalan lurus ≥ 15 m sambil mengarahkan kamera.
   Heading akan dihitung otomatis (mode *GNSS RTK lintasan*).
4. Kalibrasi titik kontrol tetap disarankan sebagai pemeriksaan silang.

## 8. Protokol uji lapangan (lakukan sebelum dipakai rutin)

1. Siapkan **8–10 titik** yang diukur surveyor (RTK/total station). Pakai 2–3 sebagai **titik kontrol**, sisanya sebagai **titik cek** (tidak boleh dimasukkan ke CSV).
2. Untuk tiap posisi berdiri (minimal 5 posisi, jarak ke titik cek 50–500 m):
   - lakukan kalibrasi;
   - arahkan tanda + ke tiap titik cek, catat E, N, RL di layar dan tekan FOTO;
   - hitung selisih terhadap koordinat surveyor.
3. Ulangi **tanpa kalibrasi** (GPS + kompas saja) sebagai pembanding.
4. **Kriteria lanjut** (usulan): median selisih horizontal ≤ 2 m pada jarak ≤ 300 m, dan ≥ 80% percobaan kalibrasi berhasil (sisa < 0,5°).
5. Kirim CSV hasil dan foto/JSON ke saya untuk dianalisis.

## 9. Keterbatasan dan K3
- **Kompas HP** terganggu logam dan kendaraan (studi: rata-rata 12° di dalam ruangan). Kalibrasi titik kontrol mengatasinya.
- **ARCore** butuh tekstur dan cahaya. Debu tebal, permukaan seragam, atau gerak cepat bisa membuat tracking hilang. Drift ±0,1–1% dari jarak berjalan, jadi kalibrasi ulang setelah berjalan jauh.
- **DEM** berasal dari tanggal situasi. Area yang berubah (front dumping, stockpile) membuat pembacaan RL topo dan gali/timbun tidak mutakhir.
- **Garis di bawah permukaan** tetap digambar (tembus tanah, tanpa hidden-line removal).
- **K3:** jangan berjalan sambil menatap layar, terutama dekat crest. Penggunaan HP di area aktif mengikuti SOP dan izin KTT.

## 10. Untuk pengembang
- **Penyelarasan:** `ENU = Rz(θ)·A(p_ar) + t`, dengan `A(x,y,z) = (x, −z, y)` (dunia ARCore Y ke atas). Detail di `core/Align.kt`.
- **Solver titik kontrol:** Levenberg–Marquardt pada residu azimut dan elevasi (σ 0,3°) + prior lemah dari GNSS. Dengan 3 bidikan tanpa noise, solver eksak.
- **Uji core:** `kotlinc app/src/main/java/id/desainar/core/*.kt test/CoreTests.kt -include-runtime -d t.jar && java -jar t.jar`
  - UTM cocok dengan pyproj EPSG:32750 (< 1 mm), konvergensi meridian cocok sampai 1e-6°.
  - Fit RTK: heading ±0,02°.
  - 1 bidikan: salah arah 11,7° → 0,19°.
- **Rencana berikut:** registrasi visual otomatis (skill 3d-to-image) dari foto → pose. Untuk sudut pandang darat, butuh pengujian dulu.
