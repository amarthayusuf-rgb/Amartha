package id.desainar.app

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import kotlin.math.*

/**
 * GNSS (LocationManager, provider GPS) + kompas (rotation vector).
 * GNSS RTK eksternal: pakai aplikasi NTRIP/mock-location (mis. Lefebure, SW Maps, Emlid Flow)
 * yang menyuntikkan posisi ke provider GPS — aplikasi ini otomatis memakainya.
 */
class GeoSensors(ctx: Context) : SensorEventListener {
    private val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rot = FloatArray(9)

    @Volatile var lastLocation: Location? = null
        private set
    /** Azimut magnetik sumbu kamera belakang (derajat), rata-rata sirkular ~0,5 detik. */
    @Volatile var cameraAzMag: Double = Double.NaN
        private set
    @Volatile var compassReliable = false
        private set
    @Volatile var compassAccuracyDeg: Double = Double.NaN
        private set

    private var sumS = 0.0
    private var sumC = 0.0
    private val win = ArrayDeque<Double>()

    var onLocation: ((Location) -> Unit)? = null

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastLocation = location
            onLocation?.invoke(location)
        }
        @Deprecated("API lama") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    @SuppressLint("MissingPermission")
    fun start() {
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500L, 0f, locListener, Looper.getMainLooper())
        } catch (e: SecurityException) { /* izin belum diberikan */ }
        catch (e: IllegalArgumentException) { /* tidak ada provider GPS */ }
        sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        lm.removeUpdates(locListener)
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(ev: SensorEvent) {
        if (ev.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        SensorManager.getRotationMatrixFromVector(rot, ev.values)
        // arah kamera belakang = -Z perangkat; dunia: X timur, Y utara magnetik, Z atas
        val wx = -rot[2].toDouble(); val wy = -rot[5].toDouble(); val wz = -rot[8].toDouble()
        compassReliable = abs(wz) < 0.85
        if (ev.values.size >= 5 && ev.values[4] > 0f) compassAccuracyDeg = Math.toDegrees(ev.values[4].toDouble())
        val az = atan2(wx, wy)
        win.addLast(az); sumS += sin(az); sumC += cos(az)
        while (win.size > 12) { val o = win.removeFirst(); sumS -= sin(o); sumC -= cos(o) }
        var deg = Math.toDegrees(atan2(sumS, sumC))
        if (deg < 0) deg += 360.0
        cameraAzMag = deg
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /** Deklinasi magnetik (derajat, timur positif) di lokasi terakhir. */
    fun declination(): Double {
        val l = lastLocation ?: return 0.0
        return GeomagneticField(l.latitude.toFloat(), l.longitude.toFloat(), l.altitude.toFloat(), System.currentTimeMillis()).declination.toDouble()
    }
}
