package id.desainar.core

import kotlin.math.*

/**
 * Transformasi dunia ARCore -> koordinat lokal proyek (E, N, RL), meter.
 *
 * Dunia ARCore: Y ke atas (searah gravitasi terbalik), X dan Z horizontal, right-handed.
 * Pemetaan sumbu: A(x, y, z) = (x, -z, y)  -> (e', n', u'), tetap right-handed.
 * Lalu:  ENU = Rz(theta) * A(p_ar) + t,  Rz berlawanan jarum jam di bidang E-N.
 * Karena itu azimut (searah jarum jam dari utara) berkurang theta:  az_enu = az_ar - theta.
 */
data class AlignParams(val theta: Double, val tx: Double, val ty: Double, val tz: Double) {
    companion object { val IDENTITY = AlignParams(0.0, 0.0, 0.0, 0.0) }
}

object Frames {
    fun arToEnu(p: AlignParams, x: Double, y: Double, z: Double): DoubleArray {
        val e0 = x; val n0 = -z; val u0 = y
        val c = cos(p.theta); val s = sin(p.theta)
        return doubleArrayOf(c * e0 - s * n0 + p.tx, s * e0 + c * n0 + p.ty, u0 + p.tz)
    }

    fun dirArToEnu(p: AlignParams, x: Double, y: Double, z: Double): DoubleArray {
        val e0 = x; val n0 = -z; val u0 = y
        val c = cos(p.theta); val s = sin(p.theta)
        return doubleArrayOf(c * e0 - s * n0, s * e0 + c * n0, u0)
    }

    /** ENU lokal -> dunia AR. Return [x, y, z]. */
    fun enuToAr(p: AlignParams, e: Double, n: Double, u: Double): DoubleArray {
        val de = e - p.tx; val dn = n - p.ty; val du = u - p.tz
        val c = cos(-p.theta); val s = sin(-p.theta)
        val e0 = c * de - s * dn
        val n0 = s * de + c * dn
        return doubleArrayOf(e0, du, -n0)
    }

    /** Azimut searah jarum jam dari utara, derajat [0, 360). */
    fun azimuthDeg(e: Double, n: Double): Double {
        var a = Math.toDegrees(atan2(e, n))
        if (a < 0) a += 360.0
        return a
    }

    fun elevationDeg(e: Double, n: Double, u: Double): Double = Math.toDegrees(atan2(u, hypot(e, n)))

    fun wrapDeg(a: Double): Double {
        var x = (a + 180.0) % 360.0
        if (x < 0) x += 360.0
        return x - 180.0
    }
}

/** Satu fix GNSS dipasangkan dengan posisi kamera AR pada saat yang sama. */
data class GnssSample(
    val arX: Double, val arY: Double, val arZ: Double,
    val e: Double, val n: Double, val u: Double,
    val accH: Double, val accV: Double
)

/** Satu bidikan titik kontrol: posisi + arah kamera AR saat tanda + tepat di titik. */
data class Sighting(
    val camX: Double, val camY: Double, val camZ: Double,
    val dirX: Double, val dirY: Double, val dirZ: Double,
    val pe: Double, val pn: Double, val pu: Double,
    val name: String
)

data class SolveResult(val params: AlignParams, val rmsDeg: Double, val residualsDeg: List<Double>, val iterations: Int)

object Aligner {

    /**
     * Penyelarasan awal dari GNSS + kompas.
     * @param fwd arah pandang kamera di dunia AR (vektor, tidak harus satuan)
     * @param gridAzDeg azimut grid arah pandang kamera dari kompas (sudah + deklinasi + konvergensi)
     * @param camE,camN,camU posisi kamera di koordinat lokal proyek
     */
    fun fromCompass(
        camX: Double, camY: Double, camZ: Double,
        fwdX: Double, fwdY: Double, fwdZ: Double,
        camE: Double, camN: Double, camU: Double,
        gridAzDeg: Double
    ): AlignParams {
        val azAr = Frames.azimuthDeg(fwdX, -fwdZ)
        val theta = Math.toRadians(Frames.wrapDeg(azAr - gridAzDeg))
        val tmp = Frames.arToEnu(AlignParams(theta, 0.0, 0.0, 0.0), camX, camY, camZ)
        return AlignParams(theta, camE - tmp[0], camN - tmp[1], camU - tmp[2])
    }

    /** Hitung ulang translasi (theta tetap) = rata-rata berbobot dari semua sampel GNSS. */
    fun fitTranslation(samples: List<GnssSample>, theta: Double): AlignParams? {
        if (samples.isEmpty()) return null
        var sw = 0.0; var se = 0.0; var sn = 0.0; var swv = 0.0; var su = 0.0
        val p0 = AlignParams(theta, 0.0, 0.0, 0.0)
        for (s in samples) {
            val q = Frames.arToEnu(p0, s.arX, s.arY, s.arZ)
            val w = 1.0 / max(s.accH * s.accH, 1e-4)
            val wv = 1.0 / max(s.accV * s.accV, 1e-4)
            se += w * (s.e - q[0]); sn += w * (s.n - q[1]); sw += w
            su += wv * (s.u - q[2]); swv += wv
        }
        return AlignParams(theta, se / sw, sn / sw, su / swv)
    }

    /**
     * Estimasi theta + translasi dari lintasan berjalan (butuh GNSS akurat, mis. RTK).
     * @return Pair(params, perkiraan sigma heading derajat) atau null jika bentang lintasan kurang.
     */
    fun fitYawAndTranslation(samples: List<GnssSample>, minSpanM: Double = 15.0): Pair<AlignParams, Double>? {
        if (samples.size < 5) return null
        val p0 = AlignParams.IDENTITY
        val a = samples.map { Frames.arToEnu(p0, it.arX, it.arY, it.arZ) }
        val w = samples.map { 1.0 / max(it.accH * it.accH, 1e-4) }
        val sw = w.sum()
        val ae = a.indices.sumOf { w[it] * a[it][0] } / sw
        val an = a.indices.sumOf { w[it] * a[it][1] } / sw
        val be = samples.indices.sumOf { w[it] * samples[it].e } / sw
        val bn = samples.indices.sumOf { w[it] * samples[it].n } / sw
        var span = 0.0
        for (i in a.indices) span = max(span, hypot(a[i][0] - ae, a[i][1] - an))
        if (span < minSpanM / 2) return null
        var sCross = 0.0; var sDot = 0.0
        for (i in a.indices) {
            val ax = a[i][0] - ae; val ay = a[i][1] - an
            val bx = samples[i].e - be; val by = samples[i].n - bn
            sCross += w[i] * (ax * by - ay * bx)
            sDot += w[i] * (ax * bx + ay * by)
        }
        val theta = atan2(sCross, sDot)
        val fit = fitTranslation(samples, theta) ?: return null
        val sigH = sqrt(samples.size / sw)                 // sigma posisi rata-rata
        val sigmaHeadingDeg = Math.toDegrees(sigH / (span * sqrt(samples.size.toDouble())))
        return Pair(fit, sigmaHeadingDeg)
    }

    /**
     * Penyelesaian Levenberg-Marquardt dari bidikan titik kontrol.
     * Residu: beda azimut & elevasi (derajat) antara arah bidikan dan arah kamera->titik.
     * Prior lemah dari penyelarasan sekarang (GNSS) menahan parameter yang tidak teramati.
     */
    fun solveSightings(
        obs: List<Sighting>, prior: AlignParams,
        sigmaH: Double, sigmaV: Double, sigmaAngDeg: Double = 0.3, sigmaThetaDeg: Double = 30.0
    ): SolveResult {
        var p = doubleArrayOf(prior.theta, prior.tx, prior.ty, prior.tz)
        val pri = p.copyOf()
        fun residuals(q: DoubleArray): DoubleArray {
            val ap = AlignParams(q[0], q[1], q[2], q[3])
            val r = ArrayList<Double>()
            for (o in obs) {
                val c = Frames.arToEnu(ap, o.camX, o.camY, o.camZ)
                val d = Frames.dirArToEnu(ap, o.dirX, o.dirY, o.dirZ)
                val ve = o.pe - c[0]; val vn = o.pn - c[1]; val vu = o.pu - c[2]
                r.add(Frames.wrapDeg(Frames.azimuthDeg(d[0], d[1]) - Frames.azimuthDeg(ve, vn)) / sigmaAngDeg)
                r.add((Frames.elevationDeg(d[0], d[1], d[2]) - Frames.elevationDeg(ve, vn, vu)) / sigmaAngDeg)
            }
            r.add(Math.toDegrees(q[0] - pri[0]) / sigmaThetaDeg)
            r.add((q[1] - pri[1]) / sigmaH)
            r.add((q[2] - pri[2]) / sigmaH)
            r.add((q[3] - pri[3]) / sigmaV)
            return r.toDoubleArray()
        }
        fun cost(r: DoubleArray) = r.sumOf { it * it }
        var r = residuals(p)
        var c = cost(r)
        var lambda = 1e-3
        val steps = doubleArrayOf(1e-6, 1e-3, 1e-3, 1e-3)
        var iter = 0
        while (iter < 50) {
            iter++
            val m = r.size
            val jac = Array(m) { DoubleArray(4) }
            for (k in 0 until 4) {
                val q = p.copyOf(); q[k] += steps[k]
                val rq = residuals(q)
                for (i in 0 until m) jac[i][k] = (rq[i] - r[i]) / steps[k]
            }
            val jtj = Array(4) { DoubleArray(4) }
            val jtr = DoubleArray(4)
            for (i in 0 until m) for (a in 0 until 4) {
                jtr[a] += jac[i][a] * r[i]
                for (b in 0 until 4) jtj[a][b] += jac[i][a] * jac[i][b]
            }
            var improved = false
            for (tries in 0 until 10) {
                val h = Array(4) { a -> DoubleArray(4) { b -> jtj[a][b] + if (a == b) lambda * (jtj[a][a] + 1e-12) else 0.0 } }
                val delta = solve4(h, DoubleArray(4) { k -> -jtr[k] }) ?: break
                val q = DoubleArray(4) { k -> p[k] + delta[k] }
                val rq = residuals(q)
                val cq = cost(rq)
                if (cq < c) {
                    p = q; r = rq
                    val conv = (c - cq) < 1e-10 * (1 + c)
                    c = cq; lambda = max(lambda / 10, 1e-12); improved = true
                    if (conv) iter = 1000
                    break
                } else lambda *= 10
            }
            if (!improved) break
        }
        val ap = AlignParams(p[0], p[1], p[2], p[3])
        val res = ArrayList<Double>()
        for (o in obs) {
            val cc = Frames.arToEnu(ap, o.camX, o.camY, o.camZ)
            val d = Frames.dirArToEnu(ap, o.dirX, o.dirY, o.dirZ)
            val ve = o.pe - cc[0]; val vn = o.pn - cc[1]; val vu = o.pu - cc[2]
            val dh = Frames.wrapDeg(Frames.azimuthDeg(d[0], d[1]) - Frames.azimuthDeg(ve, vn))
            val dv = Frames.elevationDeg(d[0], d[1], d[2]) - Frames.elevationDeg(ve, vn, vu)
            res.add(hypot(dh, dv))
        }
        val rms = if (res.isEmpty()) 0.0 else sqrt(res.sumOf { it * it } / res.size)
        return SolveResult(ap, rms, res, min(iter, 50))
    }

    /** Gauss elimination 4x4 dengan pivot. */
    private fun solve4(a0: Array<DoubleArray>, b0: DoubleArray): DoubleArray? {
        val n = b0.size
        val a = Array(n) { a0[it].copyOf() }; val b = b0.copyOf()
        for (col in 0 until n) {
            var piv = col
            for (r in col + 1 until n) if (abs(a[r][col]) > abs(a[piv][col])) piv = r
            if (abs(a[piv][col]) < 1e-18) return null
            val tr = a[col]; a[col] = a[piv]; a[piv] = tr
            val tb = b[col]; b[col] = b[piv]; b[piv] = tb
            for (r in col + 1 until n) {
                val f = a[r][col] / a[col][col]
                for (k in col until n) a[r][k] -= f * a[col][k]
                b[r] -= f * b[col]
            }
        }
        val x = DoubleArray(n)
        for (r in n - 1 downTo 0) {
            var s = b[r]
            for (k in r + 1 until n) s -= a[r][k] * x[k]
            x[r] = s / a[r][r]
        }
        return x
    }
}
