package id.desainar.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.location.Location
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Session
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.google.ar.core.exceptions.UnavailableApkTooOldException
import com.google.ar.core.exceptions.UnavailableArcoreNotInstalledException
import com.google.ar.core.exceptions.UnavailableDeviceNotCompatibleException
import com.google.ar.core.exceptions.UnavailableSdkTooOldException
import com.google.ar.core.exceptions.UnavailableUserDeclinedInstallationException
import id.desainar.core.ControlPoint
import id.desainar.core.DesignPackage
import id.desainar.core.Utm
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private var session: Session? = null
    private var installRequested = false
    private lateinit var glView: GLSurfaceView
    private lateinit var overlay: OverlayView
    private lateinit var renderer: ArRenderer
    private lateinit var sensors: GeoSensors
    private lateinit var btnLock: Button
    private val align = AlignState()
    @Volatile private var pkg: DesignPackage? = null
    private var pendingCp: ControlPoint? = null
    private var pendingStand = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        sensors = GeoSensors(this)
        sensors.onLocation = { loc -> onGnss(loc) }

        val root = FrameLayout(this)
        glView = GLSurfaceView(this).apply {
            preserveEGLContextOnPause = true
            setEGLContextClientVersion(2)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        }
        renderer = ArRenderer(
            sessionProvider = { session },
            displayRotation = { displayRotation() },
            onFrame = { overlay.postInvalidate() },
            onSnapshot = { raw, fs -> runOnUiThread { saveSnapshot(raw, fs) } }
        )
        glView.setRenderer(renderer)
        glView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        overlay = OverlayView(this)
        overlay.align = align
        overlay.frameProvider = { renderer.latest }
        overlay.hudProvider = { hudLines() }
        root.addView(glView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // tombol bawah
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.argb(110, 0, 0, 0)) }
        bar.addView(button("PAKET") { pickPackage() })
        bar.addView(button("KALIBRASI") { calibrationMenu() })
        btnLock = button("KUNCI") { lockSighting() }.apply { visibility = View.GONE; setBackgroundColor(Color.rgb(200, 120, 0)) }
        bar.addView(btnLock)
        bar.addView(button("FOTO") { renderer.snapshotRequested = true })
        bar.addView(button("LAPISAN") { layerMenu() })
        bar.addView(button("RESET") { align.reset(); toast("Penyelarasan direset — kembali ke GPS + kompas") })
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        // tombol geser manual (kanan)
        val side = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.argb(110, 0, 0, 0)) }
        // nudgeYaw(-) menggeser garis ke KIRI; nudgeHeight(+) menurunkan garis (kamera dianggap lebih tinggi)
        side.addView(button("◀ 1°") { nudge(-1.0) })
        side.addView(button("1° ▶") { nudge(1.0) })
        side.addView(button("◀ 0.1°") { nudge(-0.1) })
        side.addView(button("0.1° ▶") { nudge(0.1) })
        side.addView(button("▲ 1 m") { align.nudgeHeight(-1.0) })
        side.addView(button("▼ 1 m") { align.nudgeHeight(1.0) })
        root.addView(side, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.END or Gravity.CENTER_VERTICAL))
        setContentView(root)

        PackageStore.activeDir(this)?.let { dir -> loadPackageAsync(dir) }
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 13f
        setOnClickListener { onClick() }
    }

    @Suppress("DEPRECATION")
    private fun displayRotation(): Int = windowManager.defaultDisplay.rotation

    // ------------------------------------------------------------------ lifecycle
    override fun onResume() {
        super.onResume()
        if (!hasPermissions()) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 1)
            return
        }
        if (session == null) {
            val msg: String? = try {
                when (ArCoreApk.getInstance().requestInstall(this, !installRequested)) {
                    ArCoreApk.InstallStatus.INSTALL_REQUESTED -> { installRequested = true; return }
                    else -> {}
                }
                val s = Session(this)
                val cfg = Config(s)
                cfg.setFocusMode(Config.FocusMode.AUTO)
                cfg.setUpdateMode(Config.UpdateMode.LATEST_CAMERA_IMAGE)
                cfg.setPlaneFindingMode(Config.PlaneFindingMode.DISABLED)
                cfg.setLightEstimationMode(Config.LightEstimationMode.DISABLED)
                s.configure(cfg)
                session = s
                null
            } catch (e: UnavailableArcoreNotInstalledException) { "Pasang 'Google Play Services for AR' dari Play Store" }
            catch (e: UnavailableUserDeclinedInstallationException) { "ARCore wajib dipasang" }
            catch (e: UnavailableApkTooOldException) { "Perbarui 'Google Play Services for AR'" }
            catch (e: UnavailableSdkTooOldException) { "Perbarui aplikasi ini" }
            catch (e: UnavailableDeviceNotCompatibleException) { "HP ini tidak mendukung ARCore" }
            catch (e: Exception) { "Gagal membuat sesi AR: ${e.message}" }
            if (msg != null) { toast(msg); return }
        }
        try { session?.resume() } catch (e: CameraNotAvailableException) { toast("Kamera tidak tersedia"); session = null; return }
        glView.onResume()
        sensors.start()
    }

    override fun onPause() {
        super.onPause()
        sensors.stop()
        if (session != null) { glView.onPause(); session?.pause() }
    }

    override fun onDestroy() {
        super.onDestroy()
        session?.close(); session = null
    }

    private fun hasPermissions() =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (!hasPermissions()) toast("Izin kamera dan lokasi diperlukan")
    }

    // ------------------------------------------------------------------ GNSS & penyelarasan
    private fun onGnss(loc: Location) {
        val p = pkg ?: return
        val fs = renderer.latest ?: return
        if (!fs.tracking) return
        val en = p.toLocal(loc.latitude, loc.longitude)
        val u = align.cameraHeight(p, en[0], en[1], loc.altitude, loc.hasAltitude())
        val accH = if (loc.hasAccuracy()) loc.accuracy.toDouble() else 10.0
        val accV = if (android.os.Build.VERSION.SDK_INT >= 26 && loc.hasVerticalAccuracy()) loc.verticalAccuracyMeters.toDouble() else accH * 2
        if (align.params == null) {
            val az = sensors.cameraAzMag
            if (az.isNaN() || !sensors.compassReliable) return       // tunggu kamera tidak menghadap tegak lurus
            val grid = az + sensors.declination() + Utm.gridAzOfTrueNorth(loc.latitude, loc.longitude, p.utmZone, p.south)
            align.initFromCompass(fs, en[0], en[1], u, grid, accH)
        } else {
            align.addGnss(fs, en[0], en[1], u, accH, if (align.useDemHeight) 3.0 else accV)
        }
    }

    private fun nudge(deg: Double) {
        val fs = renderer.latest ?: return
        align.nudgeYaw(fs, deg)
    }

    private fun hudLines(): List<String> {
        val l = ArrayList<String>()
        val p = pkg
        l.add("DesainAR beta · " + (p?.name ?: "tanpa paket"))
        val loc = sensors.lastLocation
        if (loc == null) l.add("GNSS: menunggu fix...")
        else {
            val acc = if (loc.hasAccuracy()) loc.accuracy else Float.NaN
            l.add("GNSS ±%.2f m %s".format(acc, if (acc <= 0.1f) "(RTK)" else ""))
        }
        val az = sensors.cameraAzMag
        l.add(if (az.isNaN()) "Kompas: -" else "Kompas %.1f° %s".format(az, if (sensors.compassReliable) "" else "(HP terlalu tegak/datar)"))
        l.add("Selaras: " + align.mode.label)
        if (align.quality.isNotEmpty()) l.add("  " + align.quality)
        renderer.latest?.let { if (!it.tracking) l.add(it.trackingMsg) }
        pendingCp?.let { l.add(">> Arahkan + ke '${it.name}' lalu tekan KUNCI") }
        if (pendingStand) l.add(">> Berdiri tepat di atas titik, HP setinggi %.1f m".format(align.phoneHeight))
        return l
    }

    // ------------------------------------------------------------------ kalibrasi
    private fun calibrationMenu() {
        val p = pkg ?: run { toast("Muat paket dulu"); return }
        if (align.params == null) { toast("Tunggu penyelarasan awal GPS + kompas"); return }
        val opts = arrayOf(
            "Bidik titik kontrol (tanda + ke titik)",
            "Saya berdiri DI ATAS titik kontrol",
            "Tinggi kamera: " + (if (align.useDemHeight) "DEM + %.1f m (ganti ke GNSS)".format(align.phoneHeight) else "GNSS (ganti ke DEM)"),
            "Hapus kalibrasi (kembali ke GPS + kompas)"
        )
        AlertDialog.Builder(this).setTitle("Kalibrasi").setItems(opts) { _, which ->
            when (which) {
                0, 1 -> chooseControlPoint(p, which == 1)
                2 -> { align.useDemHeight = !align.useDemHeight; align.reset(); toast("Mode tinggi diganti; penyelarasan diulang") }
                3 -> { align.reset(); pendingCp = null; btnLock.visibility = View.GONE }
            }
        }.show()
    }

    private fun chooseControlPoint(p: DesignPackage, stand: Boolean) {
        if (p.controlPoints.isEmpty()) {
            toast("Paket tidak berisi titik kontrol. Tambahkan CSV titik kontrol di buat_paket.py"); return
        }
        val names = p.controlPoints.map { "%s  (RL %.2f)".format(it.name, it.u) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(if (stand) "Berdiri di titik" else "Bidik titik").setItems(names) { _, i ->
            val cp = p.controlPoints[i]
            val fs = renderer.latest
            if (stand) {
                if (fs == null || !fs.tracking) { toast("AR belum tracking"); return@setItems }
                align.standAt(fs, cp)
                toast("Posisi dikunci di ${cp.name}. Sekarang bidik titik lain untuk heading.")
            } else {
                pendingCp = cp
                btnLock.visibility = View.VISIBLE
                toast("Arahkan tanda + tepat ke ${cp.name}, tahan stabil, tekan KUNCI")
            }
        }.show()
    }

    private fun lockSighting() {
        val cp = pendingCp ?: return
        val fs = renderer.latest
        if (fs == null || !fs.tracking) { toast("AR belum tracking"); return }
        val res = align.addSighting(fs, cp)
        pendingCp = null
        btnLock.visibility = View.GONE
        if (res != null) toast("Terkunci. %d titik, sisa %.2f°".format(align.sightingCount, res.rmsDeg))
    }

    private fun layerMenu() {
        val p = pkg ?: run { toast("Muat paket dulu"); return }
        val labels = p.layers.map { it.label }.toMutableList()
        labels.add("Label RL"); labels.add("Tanda + dan gali/timbun")
        val checked = BooleanArray(labels.size) { i ->
            when {
                i < p.layers.size -> p.layers[i].visible
                i == p.layers.size -> overlay.showLabels
                else -> overlay.showCrosshair
            }
        }
        AlertDialog.Builder(this).setTitle("Lapisan (jarak maks %.0f m)".format(overlay.maxDistance))
            .setMultiChoiceItems(labels.toTypedArray(), checked) { _, i, on ->
                when {
                    i < p.layers.size -> p.layers[i].visible = on
                    i == p.layers.size -> overlay.showLabels = on
                    else -> overlay.showCrosshair = on
                }
            }
            .setPositiveButton("OK", null)
            .setNeutralButton("Jarak maks") { _, _ ->
                val opts = arrayOf("500 m", "1000 m", "1500 m", "2500 m")
                AlertDialog.Builder(this).setItems(opts) { _, k -> overlay.maxDistance = doubleArrayOf(500.0, 1000.0, 1500.0, 2500.0)[k] }.show()
            }.show()
    }

    // ------------------------------------------------------------------ paket
    private fun pickPackage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_ZIP)
    }

    @Deprecated("Activity API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_ZIP && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            toast("Memuat paket...")
            thread {
                try {
                    val dir = PackageStore.importZip(this, uri)
                    loadPackageAsync(dir)
                } catch (e: Exception) {
                    runOnUiThread { toast("Gagal memuat: ${e.message}") }
                }
            }
        }
    }

    private fun loadPackageAsync(dir: java.io.File) {
        thread {
            try {
                val p = PackageStore.load(dir)
                runOnUiThread {
                    pkg = p
                    overlay.pkg = p
                    align.reset()
                    toast("Paket '${p.name}': ${p.lines.size} garis, ${p.controlPoints.size} titik kontrol")
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Paket rusak: ${e.message}") }
            }
        }
    }

    // ------------------------------------------------------------------ foto
    private fun saveSnapshot(raw: Bitmap, fs: FrameState) {
        val out = raw.copy(Bitmap.Config.ARGB_8888, true)
        overlay.drawAll(Canvas(out), fs, out.width, out.height)
        thread {
            try {
                val f = SnapshotSaver.save(this, out, raw, fs, pkg, align, sensors.lastLocation, overlay.lastReadout)
                runOnUiThread { toast("Foto disimpan: ${f.name}") }
            } catch (e: Exception) {
                runOnUiThread { toast("Gagal simpan foto: ${e.message}") }
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    companion object { private const val REQ_ZIP = 42 }
}
