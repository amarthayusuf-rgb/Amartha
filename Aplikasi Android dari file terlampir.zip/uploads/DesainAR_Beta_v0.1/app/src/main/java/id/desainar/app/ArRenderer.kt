package id.desainar.app

import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.util.Log
import com.google.ar.core.Session
import com.google.ar.core.TrackingFailureReason
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import id.desainar.core.Mat4
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Status kamera per frame, dibaca oleh OverlayView di thread UI. */
class FrameState(
    val vp: FloatArray, val invVp: FloatArray?, val view: FloatArray, val proj: FloatArray,
    val width: Int, val height: Int,
    val camX: Double, val camY: Double, val camZ: Double,
    val fwdX: Double, val fwdY: Double, val fwdZ: Double,
    val tracking: Boolean, val trackingMsg: String, val timestampNs: Long
)

class ArRenderer(
    private val sessionProvider: () -> Session?,
    private val displayRotation: () -> Int,
    private val onFrame: (FrameState) -> Unit,
    private val onSnapshot: (Bitmap, FrameState) -> Unit
) : GLSurfaceView.Renderer {

    private val background = BackgroundQuad()
    private var width = 1
    private var height = 1
    private var geometryChanged = true
    @Volatile var snapshotRequested = false
    @Volatile var latest: FrameState? = null
        private set
    private val view = FloatArray(16)
    private val proj = FloatArray(16)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.05f, 0.05f, 0.05f, 1f)
        background.createOnGlThread()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = w; height = h
        GLES20.glViewport(0, 0, w, h)
        geometryChanged = true
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val session = sessionProvider() ?: return
        try {
            if (geometryChanged) {
                session.setDisplayGeometry(displayRotation(), width, height)
                geometryChanged = false
            }
            session.setCameraTextureNames(intArrayOf(background.textureId))
            val frame = session.update()
            background.draw(frame)
            val camera = frame.camera
            val tracking = camera.trackingState == TrackingState.TRACKING
            val msg = when {
                tracking -> "AR tracking OK"
                camera.trackingState == TrackingState.PAUSED -> when (camera.trackingFailureReason) {
                    TrackingFailureReason.INSUFFICIENT_LIGHT -> "AR: cahaya kurang"
                    TrackingFailureReason.EXCESSIVE_MOTION -> "AR: gerakan terlalu cepat"
                    TrackingFailureReason.INSUFFICIENT_FEATURES -> "AR: tekstur kurang, arahkan ke tanah/objek"
                    TrackingFailureReason.CAMERA_UNAVAILABLE -> "AR: kamera dipakai aplikasi lain"
                    else -> "AR: menginisialisasi... gerakkan HP perlahan"
                }
                else -> "AR berhenti"
            }
            camera.getViewMatrix(view, 0)
            camera.getProjectionMatrix(proj, 0, 0.1f, 5000f)
            val vp = Mat4.mul(proj, view)
            val pose = camera.displayOrientedPose
            // arah pandang kamera di dunia AR = -(baris ke-3 rotasi view)
            val fs = FrameState(
                vp, Mat4.invert(vp), view.copyOf(), proj.copyOf(), width, height,
                pose.tx().toDouble(), pose.ty().toDouble(), pose.tz().toDouble(),
                -view[2].toDouble(), -view[6].toDouble(), -view[10].toDouble(),
                tracking, msg, frame.timestamp
            )
            latest = fs
            onFrame(fs)
            if (snapshotRequested) {
                snapshotRequested = false
                onSnapshot(readPixels(), fs)
            }
        } catch (e: CameraNotAvailableException) {
            Log.w(TAG, "Kamera tidak tersedia", e)
        } catch (t: Throwable) {
            Log.e(TAG, "Error di frame", t)
        }
    }

    private fun readPixels(): Bitmap {
        val buf = ByteBuffer.allocateDirect(width * height * 4).order(ByteOrder.nativeOrder())
        GLES20.glReadPixels(0, 0, width, height, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
        buf.rewind()
        val raw = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(buf)
        val m = android.graphics.Matrix()
        m.preScale(1f, -1f)
        val flipped = Bitmap.createBitmap(raw, 0, 0, width, height, m, false)
        raw.recycle()
        return flipped.copy(Bitmap.Config.ARGB_8888, true)
    }

    companion object { private const val TAG = "DesainAR" }
}
