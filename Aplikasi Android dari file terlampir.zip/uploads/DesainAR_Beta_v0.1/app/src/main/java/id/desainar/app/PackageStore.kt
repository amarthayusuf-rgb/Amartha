package id.desainar.app

import android.content.Context
import android.graphics.Color
import android.net.Uri
import id.desainar.core.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipInputStream

/**
 * Paket desain = file .zip berisi:
 *   manifest.json   metadata, origin UTM, info DEM, titik kontrol
 *   lines.json      lapisan, garis 3D, label RL
 *   dem_topo.bin    float32 little-endian (opsional)
 *   dem_design.bin  float32 little-endian (opsional)
 */
object PackageStore {
    private const val PREF = "desainar"
    private const val KEY_ACTIVE = "paket_aktif"

    fun rootDir(ctx: Context): File = File(ctx.filesDir, "paket").apply { mkdirs() }

    /** Salin + ekstrak zip dari Storage Access Framework. Return folder hasil. */
    fun importZip(ctx: Context, uri: Uri): File {
        val name = "paket_" + System.currentTimeMillis()
        val dir = File(rootDir(ctx), name)
        dir.mkdirs()
        val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Tidak bisa membuka file")
        ZipInputStream(input.buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outName = File(entry.name).name               // ratakan subfolder, cegah path traversal
                if (!entry.isDirectory && outName.isNotEmpty()) {
                    File(dir, outName).outputStream().use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        if (!File(dir, "manifest.json").exists()) {
            dir.deleteRecursively()
            throw IllegalStateException("manifest.json tidak ditemukan di zip — bukan paket DesainAR")
        }
        setActive(ctx, dir)
        return dir
    }

    fun setActive(ctx: Context, dir: File) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_ACTIVE, dir.absolutePath).apply()
    }

    fun activeDir(ctx: Context): File? {
        val p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_ACTIVE, null) ?: return null
        val f = File(p)
        return if (File(f, "manifest.json").exists()) f else null
    }

    fun load(dir: File): DesignPackage {
        val man = JSONObject(File(dir, "manifest.json").readText())
        require(man.optString("format").startsWith("desainar-1")) { "Format paket tidak dikenal: ${man.optString("format")}" }
        val origin = man.getJSONArray("origin")
        val oE = origin.getDouble(0); val oN = origin.getDouble(1)

        val lj = JSONObject(File(dir, man.optString("lines_file", "lines.json")).readText())
        val layers = ArrayList<Layer>()
        val la = lj.getJSONArray("layers")
        for (i in 0 until la.length()) {
            val o = la.getJSONObject(i)
            layers.add(Layer(o.getString("id"), o.optString("label", o.getString("id")),
                Color.parseColor(o.optString("color", "#FFFFFF")), o.optDouble("width", 2.0).toFloat(),
                o.optBoolean("visible", true)))
        }
        val lines = ArrayList<DesignLine>()
        val arr = lj.getJSONArray("lines")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val pts = o.getJSONArray("pts")
            val d = DoubleArray(pts.length() * 3)
            for (k in 0 until pts.length()) {
                val p = pts.getJSONArray(k)
                d[3 * k] = p.getDouble(0); d[3 * k + 1] = p.getDouble(1); d[3 * k + 2] = p.getDouble(2)
            }
            if (d.size >= 6) lines.add(DesignLine(o.getString("layer"), d))
        }
        val labels = ArrayList<Label>()
        val lb = lj.optJSONArray("labels") ?: JSONArray()
        for (i in 0 until lb.length()) {
            val o = lb.getJSONObject(i)
            labels.add(Label(o.getString("text"), o.getDouble("e"), o.getDouble("n"), o.getDouble("u")))
        }
        val cps = ArrayList<ControlPoint>()
        val cp = man.optJSONArray("control_points") ?: JSONArray()
        for (i in 0 until cp.length()) {
            val o = cp.getJSONObject(i)
            cps.add(ControlPoint(o.getString("name"), o.getDouble("e"), o.getDouble("n"), o.getDouble("u")))
        }
        return DesignPackage(
            name = man.optString("name", dir.name),
            epsg = man.optInt("epsg", 32750),
            utmZone = man.optInt("utm_zone", 50),
            south = man.optBoolean("south", true),
            originE = oE, originN = oN,
            layers = layers, lines = lines, labels = labels, controlPoints = cps,
            demTopo = man.optJSONObject("dem_topo")?.let { loadDem(dir, it) },
            demDesign = man.optJSONObject("dem_design")?.let { loadDem(dir, it) },
            notes = man.optString("notes", "")
        )
    }

    private fun loadDem(dir: File, o: JSONObject): DemGrid? {
        val f = File(dir, o.getString("file"))
        if (!f.exists()) return null
        val nx = o.getInt("nx"); val ny = o.getInt("ny")
        val bytes = FileInputStream(f).use { it.readBytes() }
        require(bytes.size == nx * ny * 4) { "Ukuran ${f.name} tidak cocok dengan nx*ny" }
        val fb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
        val data = FloatArray(nx * ny)
        fb.get(data)
        return DemGrid(o.getDouble("x0"), o.getDouble("y0"), o.getDouble("cs"), nx, ny, data, o.optDouble("nodata", -9999.0).toFloat())
    }
}
