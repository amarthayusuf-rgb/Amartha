package id.desainar.core

import kotlin.math.*

/**
 * Proyeksi WGS84 lintang/bujur -> UTM (Transverse Mercator, deret Krüger orde n^4).
 * Akurasi sub-milimeter di dalam zona (diuji terhadap pyproj EPSG:32750).
 */
object Utm {
    private const val A_WGS = 6378137.0
    private const val F_WGS = 1.0 / 298.257223563
    private const val K0 = 0.9996

    private val n = F_WGS / (2.0 - F_WGS)
    private val bigA = A_WGS / (1.0 + n) * (1.0 + n * n / 4.0 + n.pow(4) / 64.0)
    private val alpha = doubleArrayOf(
        n / 2.0 - 2.0 / 3.0 * n * n + 5.0 / 16.0 * n.pow(3) + 41.0 / 180.0 * n.pow(4),
        13.0 / 48.0 * n * n - 3.0 / 5.0 * n.pow(3) + 557.0 / 1440.0 * n.pow(4),
        61.0 / 240.0 * n.pow(3) - 103.0 / 140.0 * n.pow(4),
        49561.0 / 161280.0 * n.pow(4)
    )
    private val c2n = 2.0 * sqrt(n) / (1.0 + n)

    /** @return [Easting, Northing] dalam meter. */
    fun forward(latDeg: Double, lonDeg: Double, zone: Int, south: Boolean): DoubleArray {
        val phi = Math.toRadians(latDeg)
        val lam0 = Math.toRadians(zone * 6.0 - 183.0)
        val dl = Math.toRadians(lonDeg) - lam0
        val sphi = sin(phi)
        val t = sinh(atanh(sphi) - c2n * atanh(c2n * sphi))
        val xiP = atan2(t, cos(dl))
        val etaP = atanh(sin(dl) / sqrt(1.0 + t * t))
        var xi = xiP
        var eta = etaP
        for (j in 1..4) {
            xi += alpha[j - 1] * sin(2.0 * j * xiP) * cosh(2.0 * j * etaP)
            eta += alpha[j - 1] * cos(2.0 * j * xiP) * sinh(2.0 * j * etaP)
        }
        val e = 500000.0 + K0 * bigA * eta
        val nn = (if (south) 10000000.0 else 0.0) + K0 * bigA * xi
        return doubleArrayOf(e, nn)
    }

    /**
     * Azimut grid (searah jarum jam dari utara grid) dari arah utara sebenarnya, derajat.
     * grid_az = true_az + gridAzOfTrueNorth(...). Dihitung numerik supaya tanda tidak tertukar.
     */
    fun gridAzOfTrueNorth(latDeg: Double, lonDeg: Double, zone: Int, south: Boolean): Double {
        val d = 1e-5
        val p0 = forward(latDeg, lonDeg, zone, south)
        val p1 = forward(latDeg + d, lonDeg, zone, south)
        return Math.toDegrees(atan2(p1[0] - p0[0], p1[1] - p0[1]))
    }
}
