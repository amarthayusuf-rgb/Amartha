package id.desainar.core

/** Isi paket desain (dibuat oleh tools/buat_paket.py). Semua koordinat lokal = UTM - origin. */
data class Layer(val id: String, val label: String, val color: Int, val widthDp: Float, var visible: Boolean = true)

/** pts = [e0,n0,u0, e1,n1,u1, ...] koordinat lokal proyek. */
class DesignLine(val layer: String, val pts: DoubleArray)

data class Label(val text: String, val e: Double, val n: Double, val u: Double)

data class ControlPoint(val name: String, val e: Double, val n: Double, val u: Double)

class DesignPackage(
    val name: String,
    val epsg: Int,
    val utmZone: Int,
    val south: Boolean,
    val originE: Double,
    val originN: Double,
    val layers: List<Layer>,
    val lines: List<DesignLine>,
    val labels: List<Label>,
    val controlPoints: List<ControlPoint>,
    val demTopo: DemGrid?,
    val demDesign: DemGrid?,
    val notes: String
) {
    fun layer(id: String): Layer? = layers.firstOrNull { it.id == id }

    /** Lintang/bujur -> lokal (E, N). */
    fun toLocal(latDeg: Double, lonDeg: Double): DoubleArray {
        val en = Utm.forward(latDeg, lonDeg, utmZone, south)
        return doubleArrayOf(en[0] - originE, en[1] - originN)
    }
}
