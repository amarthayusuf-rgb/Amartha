package id.desainar.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.location.Location
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import id.desainar.core.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Simpan foto ber-overlay (JPG) + metadata pose (JSON) supaya bisa diregistrasi ulang
 * secara presisi di PC/cloud dengan skill 3d-to-image (kamera, intrinsik, penyelarasan).
 */
object SnapshotSaver {
    fun save(ctx: Context, bmp: Bitmap, raw: Bitmap?, fs: FrameState, pkg: DesignPackage?, align: AlignState,
             loc: Location?, readout: String): File {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "DesainAR").apply { mkdirs() }
        val jpg = File(dir, "DesainAR_$stamp.jpg")
        jpg.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        raw?.let { r -> File(dir, "DesainAR_${stamp}_asli.jpg").outputStream().use { r.compress(Bitmap.CompressFormat.JPEG, 95, it) } }

        val m = JSONObject()
        m.put("waktu", stamp)
        m.put("paket", pkg?.name ?: "")
        pkg?.let { m.put("epsg", it.epsg); m.put("origin", JSONArray(listOf(it.originE, it.originN))) }
        loc?.let {
            m.put("gnss", JSONObject().put("lat", it.latitude).put("lon", it.longitude).put("alt", it.altitude)
                .put("akurasi_h", it.accuracy.toDouble()).put("provider", it.provider ?: ""))
        }
        m.put("layar", JSONArray(listOf(fs.width, fs.height)))
        m.put("view", JSONArray(fs.view.map { it.toDouble() }))
        m.put("proj", JSONArray(fs.proj.map { it.toDouble() }))
        m.put("kamera_ar", JSONArray(listOf(fs.camX, fs.camY, fs.camZ)))
        align.params?.let { p ->
            val c = Frames.arToEnu(p, fs.camX, fs.camY, fs.camZ)
            val d = Frames.dirArToEnu(p, fs.fwdX, fs.fwdY, fs.fwdZ)
            m.put("penyelarasan", JSONObject().put("theta_deg", Math.toDegrees(p.theta)).put("tx", p.tx).put("ty", p.ty).put("tz", p.tz)
                .put("mode", align.mode.name).put("kualitas", align.quality))
            if (pkg != null) m.put("kamera_utm", JSONArray(listOf(c[0] + pkg.originE, c[1] + pkg.originN, c[2])))
            m.put("arah_pandang", JSONObject().put("azimut_grid_deg", Frames.azimuthDeg(d[0], d[1]))
                .put("elevasi_deg", Frames.elevationDeg(d[0], d[1], d[2])))
            // fokus dalam piksel layar (dari matriks proyeksi OpenGL)
            m.put("fokus_px", JSONArray(listOf(fs.proj[0] * fs.width / 2.0, fs.proj[5] * fs.height / 2.0)))
        }
        m.put("tanda_plus", readout)
        File(dir, "DesainAR_$stamp.json").writeText(m.toString(2))

        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, jpg.name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DesainAR")
                }
                ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)?.let { uri ->
                    ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                }
            } catch (_: Exception) { /* galeri opsional */ }
        }
        return jpg
    }
}
