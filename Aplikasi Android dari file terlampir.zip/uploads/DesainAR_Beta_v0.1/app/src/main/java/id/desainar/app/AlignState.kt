package id.desainar.app

import id.desainar.core.*
import kotlin.math.*

/**
 * Status penyelarasan dunia AR <-> koordinat tambang.
 * Urutan sumber (dari kasar ke teliti): GPS + kompas -> GNSS RTK (lintasan) -> titik kontrol.
 */
class AlignState {
    enum class Mode(val label: String) {
        NONE("Belum selaras"), COMPASS("GPS + kompas (kasar ±10-80 m)"), RTK("GNSS RTK lintasan"),
        STAND("Berdiri di titik kontrol"), CONTROL("Titik kontrol"), MANUAL("Manual")
    }

    @Volatile var params: AlignParams? = null
        private set
    @Volatile var mode = Mode.NONE
        private set
    @Volatile var version = 0
        private set
    @Volatile var quality = ""
        private set

    /** true = jangan ditimpa GNSS lagi (setelah kalibrasi titik kontrol / manual). */
    @Volatile var locked = false
        private set
    var useDemHeight = true            // tinggi kamera = DEM + tinggi HP (default, kebal beda datum)
    var phoneHeight = 1.5
    var geoidOffset = 0.0              // tinggi elipsoid GNSS - RL (untuk mode tinggi GNSS)

    private val samples = ArrayList<GnssSample>()
    private val sightings = ArrayList<Sighting>()
    private var standFix = false
    private var lastAccH = 5.0

    val sightingCount get() = synchronized(this) { sightings.size }

    @Synchronized fun reset() {
        params = null; mode = Mode.NONE; locked = false; standFix = false
        samples.clear(); sightings.clear(); quality = ""; version++
    }

    /** Tinggi kamera di koordinat lokal (RL). */
    fun cameraHeight(pkg: DesignPackage?, e: Double, n: Double, gnssAlt: Double, hasAlt: Boolean): Double {
        if (useDemHeight) {
            val z = pkg?.demTopo?.sample(e, n) ?: Double.NaN
            if (!z.isNaN()) return z + phoneHeight
        }
        return if (hasAlt) gnssAlt - geoidOffset else 0.0
    }

    @Synchronized fun initFromCompass(fs: FrameState, camE: Double, camN: Double, camU: Double, gridAzDeg: Double, accH: Double) {
        if (locked) return
        params = Aligner.fromCompass(fs.camX, fs.camY, fs.camZ, fs.fwdX, fs.fwdY, fs.fwdZ, camE, camN, camU, gridAzDeg)
        mode = Mode.COMPASS
        lastAccH = accH
        quality = "posisi ±%.1f m, heading kompas".format(accH)
        version++
    }

    /** Tambah fix GNSS; perbarui translasi (atau heading juga bila RTK dan lintasan cukup panjang). */
    @Synchronized fun addGnss(fs: FrameState, e: Double, n: Double, u: Double, accH: Double, accV: Double) {
        lastAccH = accH
        samples.add(GnssSample(fs.camX, fs.camY, fs.camZ, e, n, u, max(accH, 0.01), max(accV, 0.02)))
        while (samples.size > 900) samples.removeAt(0)
        val p = params ?: return
        if (locked) return
        if (accH <= 0.10) {
            val good = samples.filter { it.accH <= 0.10 }
            val fit = Aligner.fitYawAndTranslation(good)
            if (fit != null && fit.second < 0.5) {
                params = fit.first; mode = Mode.RTK
                quality = "RTK, heading ±%.2f° (n=%d)".format(fit.second, good.size)
                version++
                return
            }
        }
        // theta tetap; translasi = rata-rata berbobot 120 sampel terakhir (meredam noise GNSS)
        val recent = samples.takeLast(120)
        Aligner.fitTranslation(recent, p.theta)?.let {
            params = it
            quality = "GNSS ±%.1f m, rata-rata %d fix, heading kompas".format(accH, recent.size)
            version++
        }
    }

    /** Pengguna berdiri tepat di atas titik kontrol: kunci posisi kamera (heading tetap). */
    @Synchronized fun standAt(fs: FrameState, cp: ControlPoint) {
        val p = params ?: AlignParams.IDENTITY
        val cur = Frames.arToEnu(p, fs.camX, fs.camY, fs.camZ)
        params = AlignParams(p.theta, p.tx + (cp.e - cur[0]), p.ty + (cp.n - cur[1]), p.tz + (cp.u + phoneHeight - cur[2]))
        standFix = true; locked = true; mode = Mode.STAND
        quality = "posisi = ${cp.name}; bidik 1 titik lain untuk heading"
        version++
    }

    /** Bidik titik kontrol dengan tanda + di tengah layar; selesaikan ulang dengan semua bidikan. */
    @Synchronized fun addSighting(fs: FrameState, cp: ControlPoint): SolveResult? {
        val inv = fs.invVp ?: return null
        val ray = Projector.unproject(inv, fs.width / 2f, fs.height / 2f, fs.width, fs.height)
        sightings.add(Sighting(fs.camX, fs.camY, fs.camZ, ray[3], ray[4], ray[5], cp.e, cp.n, cp.u, cp.name))
        val prior = params ?: return null
        val sH = if (standFix) 0.3 else max(lastAccH, 1.0)
        val sV = if (standFix) 0.3 else if (useDemHeight) 3.0 else 10.0
        val res = Aligner.solveSightings(sightings, prior, sH, sV)
        params = res.params; locked = true; mode = Mode.CONTROL
        quality = "%d titik, sisa %.2f°".format(sightings.size, res.rmsDeg)
        version++
        return res
    }

    /** Putar dunia di sekitar posisi kamera sekarang (kamera tidak berpindah). */
    @Synchronized fun nudgeYaw(fs: FrameState, deg: Double) {
        val p = params ?: return
        val cam = Frames.arToEnu(p, fs.camX, fs.camY, fs.camZ)
        val th = p.theta + Math.toRadians(deg)
        val tmp = Frames.arToEnu(AlignParams(th, 0.0, 0.0, 0.0), fs.camX, fs.camY, fs.camZ)
        params = AlignParams(th, cam[0] - tmp[0], cam[1] - tmp[1], p.tz)
        markManual()
    }

    @Synchronized fun nudgeHeight(dz: Double) {
        val p = params ?: return
        params = p.copy(tz = p.tz + dz)
        markManual()
    }

    private fun markManual() {
        locked = true
        if (mode != Mode.CONTROL && mode != Mode.STAND) mode = Mode.MANUAL
        version++
    }

    fun headingOffsetInfo(): String {
        val p = params ?: return "-"
        return "θ=%.2f°".format(Math.toDegrees(p.theta))
    }
}
