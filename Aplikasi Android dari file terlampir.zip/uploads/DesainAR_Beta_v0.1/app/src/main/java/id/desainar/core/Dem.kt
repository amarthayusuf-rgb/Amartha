package id.desainar.core

import kotlin.math.*

/**
 * Grid ketinggian (float32), baris dari utara ke selatan, koordinat lokal proyek.
 * x0,y0 = koordinat lokal tepi BARAT-LAUT sel pertama.
 */
class DemGrid(
    val x0: Double, val y0: Double, val cs: Double,
    val nx: Int, val ny: Int, val data: FloatArray, val nodata: Float = -9999f
) {
    fun sample(e: Double, n: Double): Double {
        val c = (e - x0) / cs - 0.5
        val r = (y0 - n) / cs - 0.5
        if (c < 0 || r < 0 || c > nx - 1 || r > ny - 1) return Double.NaN
        val c0 = floor(c).toInt().coerceIn(0, nx - 2)
        val r0 = floor(r).toInt().coerceIn(0, ny - 2)
        val fc = c - c0; val fr = r - r0
        val z00 = v(r0, c0); val z01 = v(r0, c0 + 1); val z10 = v(r0 + 1, c0); val z11 = v(r0 + 1, c0 + 1)
        if (z00.isNaN() || z01.isNaN() || z10.isNaN() || z11.isNaN()) {
            // tepi data: pakai tetangga terdekat yang valid
            val zs = listOf(z00, z01, z10, z11).filter { !it.isNaN() }
            return if (zs.isEmpty()) Double.NaN else zs.average()
        }
        return (z00 * (1 - fc) + z01 * fc) * (1 - fr) + (z10 * (1 - fc) + z11 * fc) * fr
    }

    private fun v(r: Int, c: Int): Double {
        val z = data[r * nx + c]
        return if (z == nodata || z.isNaN()) Double.NaN else z.toDouble()
    }

    /**
     * Potong sinar dengan permukaan. origin/dir di koordinat lokal (E,N,U).
     * @return [E, N, U, jarak] atau null bila tidak kena dalam maxDist.
     */
    fun raycast(o: DoubleArray, d0: DoubleArray, maxDist: Double = 2000.0, step: Double = 0.0): DoubleArray? {
        val len = sqrt(d0[0] * d0[0] + d0[1] * d0[1] + d0[2] * d0[2])
        if (len < 1e-9) return null
        val d = doubleArrayOf(d0[0] / len, d0[1] / len, d0[2] / len)
        val st = if (step > 0) step else max(cs * 0.5, 0.5)
        var sPrev = 0.0
        var above = above(o, d, 0.0) ?: true
        var s = st
        while (s <= maxDist) {
            val a = above(o, d, s)
            if (a != null && above && !a) {
                // bisection antara sPrev dan s
                var lo = sPrev; var hi = s
                repeat(30) {
                    val mid = 0.5 * (lo + hi)
                    val am = above(o, d, mid)
                    if (am == null || am) lo = mid else hi = mid
                }
                val t = 0.5 * (lo + hi)
                return doubleArrayOf(o[0] + d[0] * t, o[1] + d[1] * t, o[2] + d[2] * t, t)
            }
            if (a != null) above = a
            sPrev = s
            s += st
        }
        return null
    }

    private fun above(o: DoubleArray, d: DoubleArray, s: Double): Boolean? {
        val e = o[0] + d[0] * s; val n = o[1] + d[1] * s; val u = o[2] + d[2] * s
        val z = sample(e, n)
        if (z.isNaN()) return null
        return u > z
    }
}
