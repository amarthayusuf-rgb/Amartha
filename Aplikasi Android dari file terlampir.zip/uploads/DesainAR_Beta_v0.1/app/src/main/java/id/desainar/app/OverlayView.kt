package id.desainar.app

import android.content.Context
import android.graphics.*
import android.view.View
import id.desainar.core.*
import kotlin.math.*

/** Lapisan 2D di atas kamera: garis desain, label RL, tanda +, pembacaan gali/timbun, HUD. */
class OverlayView(ctx: Context) : View(ctx) {
    var pkg: DesignPackage? = null
        set(v) { field = v; cacheVersion = -1; postInvalidate() }
    lateinit var align: AlignState
    var frameProvider: () -> FrameState? = { null }
    var hudProvider: () -> List<String> = { emptyList() }
    var maxDistance = 1500.0
    var showLabels = true
    var showCrosshair = true
    /** Pembacaan terakhir di tanda + (dipakai juga untuk metadata foto). */
    @Volatile var lastReadout: String = ""
        private set

    private val dp = resources.displayMetrics.density
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        color = Color.argb(150, 0, 0, 0)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 13 * dp; typeface = Typeface.DEFAULT_BOLD }
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(140, 0, 0, 0) }
    private val crossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.YELLOW; strokeWidth = 2 * dp; style = Paint.Style.STROKE }

    private var cacheVersion = -1
    private var cachePkg: DesignPackage? = null
    private var arLines: List<Pair<DesignLine, DoubleArray>> = emptyList()
    private var arLabels: List<Pair<Label, DoubleArray>> = emptyList()
    private val path = Path()

    private fun refreshCache() {
        val p = pkg ?: return
        val ap = align.params ?: return
        if (cacheVersion == align.version && cachePkg === p) return
        arLines = p.lines.map { l ->
            val out = DoubleArray(l.pts.size)
            var i = 0
            while (i < l.pts.size) {
                val a = Frames.enuToAr(ap, l.pts[i], l.pts[i + 1], l.pts[i + 2])
                out[i] = a[0]; out[i + 1] = a[1]; out[i + 2] = a[2]
                i += 3
            }
            Pair(l, out)
        }
        arLabels = p.labels.map { Pair(it, Frames.enuToAr(ap, it.e, it.n, it.u)) }
        cacheVersion = align.version; cachePkg = p
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawAll(canvas, frameProvider(), width, height)
    }

    /** Dipakai juga untuk menggambar di atas bitmap foto (snapshot). */
    fun drawAll(canvas: Canvas, fs: FrameState?, w: Int, h: Int) {
        val p = pkg
        if (p == null) {
            drawBox(canvas, listOf("Belum ada paket desain.", "Tekan PAKET untuk memuat file .zip dari buat_paket.py"), 12 * dp, 12 * dp)
            return
        }
        if (fs != null && fs.tracking && align.params != null) {
            refreshCache()
            val sx = w.toFloat() / fs.width; val sy = h.toFloat() / fs.height
            for ((line, pts) in arLines) {
                val layer = p.layer(line.layer) ?: continue
                if (!layer.visible) continue
                if (!withinRange(pts, fs)) continue
                val segs = Projector.projectPolyline(pts, fs.vp, fs.width, fs.height)
                if (segs.isEmpty()) continue
                linePaint.color = layer.color
                linePaint.strokeWidth = layer.widthDp * dp * 1.3f
                shadowPaint.strokeWidth = linePaint.strokeWidth + 2.5f * dp
                for (s in segs) {
                    path.reset()
                    path.moveTo(s[0] * sx, s[1] * sy)
                    var k = 2
                    while (k < s.size) { path.lineTo(s[k] * sx, s[k + 1] * sy); k += 2 }
                    canvas.drawPath(path, shadowPaint)
                    canvas.drawPath(path, linePaint)
                }
            }
            if (showLabels) for ((lab, a) in arLabels) {
                val d = hypot(a[0] - fs.camX, a[2] - fs.camZ)
                if (d > maxDistance) continue
                val s = Projector.projectPoint(fs.vp, a[0], a[1], a[2], fs.width, fs.height) ?: continue
                val x = s[0] * sx; val y = s[1] * sy
                if (x < 0 || y < 0 || x > w || y > h) continue
                val tw = textPaint.measureText(lab.text)
                canvas.drawRoundRect(x - tw / 2 - 4 * dp, y - 14 * dp, x + tw / 2 + 4 * dp, y + 4 * dp, 4 * dp, 4 * dp, boxPaint)
                canvas.drawText(lab.text, x - tw / 2, y, textPaint)
            }
            if (showCrosshair) drawCrosshair(canvas, fs, p, w, h)
        } else if (fs != null && !fs.tracking) {
            drawCenterMsg(canvas, fs.trackingMsg, w, h)
        } else if (align.params == null) {
            drawCenterMsg(canvas, "Menunggu GPS + kompas... (di area terbuka)", w, h)
        }
        drawBox(canvas, hudProvider(), 12 * dp, 12 * dp)
    }

    private fun withinRange(pts: DoubleArray, fs: FrameState): Boolean {
        var i = 0
        val m2 = maxDistance * maxDistance
        while (i < pts.size) {
            val dx = pts[i] - fs.camX; val dz = pts[i + 2] - fs.camZ
            if (dx * dx + dz * dz < m2) return true
            i += 3
        }
        return false
    }

    private fun drawCrosshair(canvas: Canvas, fs: FrameState, p: DesignPackage, w: Int, h: Int) {
        val cx = w / 2f; val cy = h / 2f; val r = 14 * dp
        canvas.drawLine(cx - r, cy, cx - 4 * dp, cy, crossPaint); canvas.drawLine(cx + 4 * dp, cy, cx + r, cy, crossPaint)
        canvas.drawLine(cx, cy - r, cx, cy - 4 * dp, crossPaint); canvas.drawLine(cx, cy + 4 * dp, cx, cy + r, crossPaint)
        val ap = align.params ?: return
        val inv = fs.invVp ?: return
        val ray = Projector.unproject(inv, fs.width / 2f, fs.height / 2f, fs.width, fs.height)
        val o = Frames.arToEnu(ap, fs.camX, fs.camY, fs.camZ)
        val d = Frames.dirArToEnu(ap, ray[3], ray[4], ray[5])
        val dem = p.demTopo
        val lines = ArrayList<String>()
        val hit = dem?.raycast(o, d, maxDistance)
        if (hit != null) {
            val zDes = p.demDesign?.sample(hit[0], hit[1]) ?: Double.NaN
            lines.add("E %.1f  N %.1f".format(hit[0] + p.originE, hit[1] + p.originN))
            lines.add("Jarak %.0f m   RL topo %.1f".format(hypot(hit[0] - o[0], hit[1] - o[1]), hit[2]))
            if (!zDes.isNaN()) {
                val dz = hit[2] - zDes
                lines.add("RL desain %.1f   %s %.1f m".format(zDes, if (dz >= 0) "GALI" else "TIMBUN", abs(dz)))
            }
        } else {
            lines.add("Tanda + tidak mengenai DEM (≤ %.0f m)".format(maxDistance))
        }
        lastReadout = lines.joinToString(" | ")
        val tw = lines.maxOf { textPaint.measureText(it) }
        drawBox(canvas, lines, cx - tw / 2f - 8 * dp, cy + r + 8 * dp)
    }

    private fun drawCenterMsg(canvas: Canvas, msg: String, w: Int, h: Int) {
        val tw = textPaint.measureText(msg)
        drawBox(canvas, listOf(msg), (w - tw) / 2f - 8 * dp, h / 2f - 20 * dp)
    }

    private fun drawBox(canvas: Canvas, lines: List<String>, x: Float, y: Float) {
        if (lines.isEmpty()) return
        val lh = 17 * dp
        val tw = lines.maxOf { textPaint.measureText(it) }
        canvas.drawRoundRect(x, y, x + tw + 16 * dp, y + lh * lines.size + 10 * dp, 6 * dp, 6 * dp, boxPaint)
        lines.forEachIndexed { i, s -> canvas.drawText(s, x + 8 * dp, y + 5 * dp + lh * (i + 1) - 4 * dp, textPaint) }
    }
}
