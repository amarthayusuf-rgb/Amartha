package id.desainar.core

import kotlin.math.*

/** Matriks 4x4 kolom-mayor (konvensi OpenGL / ARCore): m[col*4 + row]. */
object Mat4 {
    fun mul(a: FloatArray, b: FloatArray): FloatArray {
        val r = FloatArray(16)
        for (c in 0 until 4) for (rw in 0 until 4) {
            var s = 0f
            for (k in 0 until 4) s += a[k * 4 + rw] * b[c * 4 + k]
            r[c * 4 + rw] = s
        }
        return r
    }

    /** clip = m * (x, y, z, 1) -> [cx, cy, cz, cw] */
    fun mulPoint(m: FloatArray, x: Double, y: Double, z: Double, out: DoubleArray) {
        for (rw in 0 until 4) out[rw] = m[rw] * x + m[4 + rw] * y + m[8 + rw] * z + m[12 + rw]
    }

    fun invert(m: FloatArray): FloatArray? {
        val a = Array(4) { r -> DoubleArray(8) { c -> if (c < 4) m[c * 4 + r].toDouble() else if (c - 4 == r) 1.0 else 0.0 } }
        for (col in 0 until 4) {
            var piv = col
            for (r in col + 1 until 4) if (abs(a[r][col]) > abs(a[piv][col])) piv = r
            if (abs(a[piv][col]) < 1e-12) return null
            val t = a[col]; a[col] = a[piv]; a[piv] = t
            val p = a[col][col]
            for (c in 0 until 8) a[col][c] /= p
            for (r in 0 until 4) if (r != col) {
                val f = a[r][col]
                if (f != 0.0) for (c in 0 until 8) a[r][c] -= f * a[col][c]
            }
        }
        val out = FloatArray(16)
        for (r in 0 until 4) for (c in 0 until 4) out[c * 4 + r] = a[r][c + 4].toFloat()
        return out
    }
}

/**
 * Proyeksi polyline dunia-AR ke layar dengan kliping bidang dekat (clip space) dan kliping layar.
 * @param pts koordinat AR berurutan [x0,y0,z0, x1,y1,z1, ...]
 * @param vp  matriks proyeksi * view (kolom-mayor)
 * @return daftar potongan polyline di piksel layar [sx0,sy0, sx1,sy1, ...]
 */
object Projector {
    private const val NEAR_W = 0.5        // meter: titik lebih dekat dari ini dibuang

    fun projectPolyline(pts: DoubleArray, vp: FloatArray, w: Int, h: Int, margin: Double = 0.25): List<FloatArray> {
        val out = ArrayList<FloatArray>()
        val n = pts.size / 3
        if (n < 2) return out
        val ca = DoubleArray(4); val cb = DoubleArray(4)
        var cur = ArrayList<Float>()
        fun flush() { if (cur.size >= 4) out.add(cur.toFloatArray()); cur = ArrayList() }
        val x0 = -margin * w; val x1 = (1 + margin) * w; val y0 = -margin * h; val y1 = (1 + margin) * h
        for (i in 0 until n - 1) {
            Mat4.mulPoint(vp, pts[3 * i], pts[3 * i + 1], pts[3 * i + 2], ca)
            Mat4.mulPoint(vp, pts[3 * i + 3], pts[3 * i + 4], pts[3 * i + 5], cb)
            var ta = 0.0; var tb = 1.0
            val wa = ca[3]; val wb = cb[3]
            if (wa < NEAR_W && wb < NEAR_W) { flush(); continue }
            if (wa < NEAR_W) ta = (NEAR_W - wa) / (wb - wa)
            if (wb < NEAR_W) tb = (NEAR_W - wa) / (wb - wa)
            val pa = toScreen(lerp(ca, cb, ta), w, h)
            val pb = toScreen(lerp(ca, cb, tb), w, h)
            val seg = clipRect(pa[0], pa[1], pb[0], pb[1], x0, x1, y0, y1)
            if (seg == null) { flush(); continue }
            if (cur.isEmpty() || ta > 0 || abs(cur[cur.size - 2] - seg[0]) > 0.01f || abs(cur[cur.size - 1] - seg[1]) > 0.01f) {
                flush(); cur.add(seg[0]); cur.add(seg[1])
            }
            cur.add(seg[2]); cur.add(seg[3])
            if (tb < 1.0 || seg[4] < 1f) flush()
        }
        flush()
        return out
    }

    /** Titik tunggal -> layar, null bila di belakang kamera. */
    fun projectPoint(vp: FloatArray, x: Double, y: Double, z: Double, w: Int, h: Int): FloatArray? {
        val c = DoubleArray(4)
        Mat4.mulPoint(vp, x, y, z, c)
        if (c[3] < NEAR_W) return null
        val s = toScreen(c, w, h)
        return floatArrayOf(s[0].toFloat(), s[1].toFloat(), c[3].toFloat())
    }

    /** Sinar dari piksel layar (sx,sy) -> [ox,oy,oz, dx,dy,dz] di dunia AR. */
    fun unproject(invVp: FloatArray, sx: Float, sy: Float, w: Int, h: Int): DoubleArray {
        val nx = 2.0 * sx / w - 1.0
        val ny = 1.0 - 2.0 * sy / h
        val a = DoubleArray(4); val b = DoubleArray(4)
        mulNdc(invVp, nx, ny, -1.0, a)
        mulNdc(invVp, nx, ny, 1.0, b)
        val ox = a[0] / a[3]; val oy = a[1] / a[3]; val oz = a[2] / a[3]
        val fx = b[0] / b[3]; val fy = b[1] / b[3]; val fz = b[2] / b[3]
        return doubleArrayOf(ox, oy, oz, fx - ox, fy - oy, fz - oz)
    }

    private fun mulNdc(m: FloatArray, x: Double, y: Double, z: Double, out: DoubleArray) {
        for (rw in 0 until 4) out[rw] = m[rw] * x + m[4 + rw] * y + m[8 + rw] * z + m[12 + rw]
    }

    private fun lerp(a: DoubleArray, b: DoubleArray, t: Double) = DoubleArray(4) { a[it] + (b[it] - a[it]) * t }

    private fun toScreen(c: DoubleArray, w: Int, h: Int): DoubleArray {
        val nx = c[0] / c[3]; val ny = c[1] / c[3]
        return doubleArrayOf((nx + 1.0) * 0.5 * w, (1.0 - ny) * 0.5 * h)
    }

    /** Liang-Barsky. Return [xa,ya,xb,yb,t1] atau null. */
    private fun clipRect(xa: Double, ya: Double, xb: Double, yb: Double, x0: Double, x1: Double, y0: Double, y1: Double): FloatArray? {
        val dx = xb - xa; val dy = yb - ya
        var t0 = 0.0; var t1 = 1.0
        val ps = doubleArrayOf(-dx, dx, -dy, dy)
        val qs = doubleArrayOf(xa - x0, x1 - xa, ya - y0, y1 - ya)
        for (k in 0 until 4) {
            val p = ps[k]; val q = qs[k]
            if (abs(p) < 1e-12) { if (q < 0) return null }
            else {
                val r = q / p
                if (p < 0) { if (r > t1) return null; if (r > t0) t0 = r }
                else { if (r < t0) return null; if (r < t1) t1 = r }
            }
        }
        return floatArrayOf((xa + t0 * dx).toFloat(), (ya + t0 * dy).toFloat(), (xa + t1 * dx).toFloat(), (ya + t1 * dy).toFloat(), t1.toFloat())
    }
}
